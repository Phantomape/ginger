"""
Portfolio Engine: Convert signals into position sizes and enforce risk limits.

Rules per inst_5.txt:
  risk_per_trade ≤ 1% of portfolio
  position_size  = risk_amount / (entry_price − stop_price)
  portfolio_heat ≤ 8%  (total at-risk / portfolio_value)
"""

import math
import logging

from constants import (
    RISK_PER_TRADE_PCT,
    MAX_PORTFOLIO_HEAT,
    MAX_POSITION_PCT,
    LOW_TQS_RISK_THRESHOLD,
    LOW_TQS_RISK_MULTIPLIER,
    LOW_TQS_HAIRCUT_EXEMPT_SECTORS,
    LOW_TQS_BREAKOUT_NON_EXEMPT_RISK_MULTIPLIER,
    TREND_INDUSTRIALS_RISK_MULTIPLIER,
    TREND_FINANCIALS_RISK_MULTIPLIER,
    TREND_FINANCIALS_SECTOR_LEADER_RISK_MULTIPLIER,
    TREND_FINANCIALS_SECTOR_LEADER_MAX_POSITION_PCT,
    TREND_FINANCIALS_MID_DISPERSION_LEADER_MAX_POSITION_PCT,
    TREND_TECH_GAP_VULN_MIN,
    TREND_TECH_GAP_VULN_MAX,
    TREND_TECH_GAP_RISK_MULTIPLIER,
    TREND_TECH_TIGHT_GAP_VULN_MIN,
    TREND_TECH_TIGHT_GAP_VULN_MAX,
    TREND_TECH_TIGHT_GAP_RISK_MULTIPLIER,
    TREND_TECH_NEAR_HIGH_MAX_PULLBACK,
    TREND_TECH_NEAR_HIGH_RISK_MULTIPLIER,
    BREAKOUT_INDUSTRIALS_GAP_VULN_MIN,
    BREAKOUT_INDUSTRIALS_GAP_VULN_MAX,
    BREAKOUT_INDUSTRIALS_GAP_RISK_MULTIPLIER,
    BREAKOUT_COMMS_NEAR_HIGH_MAX_PULLBACK,
    BREAKOUT_COMMS_NEAR_HIGH_RISK_MULTIPLIER,
    BREAKOUT_COMMS_GAP_VULN_MIN,
    BREAKOUT_COMMS_GAP_VULN_MAX,
    BREAKOUT_COMMS_GAP_RISK_MULTIPLIER,
    BREAKOUT_FINANCIALS_DTE_MIN,
    BREAKOUT_FINANCIALS_DTE_MAX,
    BREAKOUT_FINANCIALS_DTE_RISK_MULTIPLIER,
    BREAKOUT_TECH_DTE_MIN,
    BREAKOUT_TECH_DTE_MAX,
    BREAKOUT_TECH_DTE_RISK_MULTIPLIER,
    BREAKOUT_HEALTHCARE_DTE_MIN,
    BREAKOUT_HEALTHCARE_DTE_MAX,
    BREAKOUT_HEALTHCARE_DTE_RISK_MULTIPLIER,
    BREAKOUT_COMMODITIES_MAX_POSITION_PCT,
    TREND_TECH_DTE_MIN,
    TREND_TECH_DTE_MAX,
    TREND_TECH_DTE_RISK_MULTIPLIER,
    TSM_CORE_RISK_MULTIPLIER,
    ISRG_CORE_RISK_MULTIPLIER,
    TREND_HEALTHCARE_DTE_MIN,
    TREND_HEALTHCARE_DTE_MAX,
    TREND_HEALTHCARE_DTE_RISK_MULTIPLIER,
    TREND_CONSUMER_NEAR_HIGH_DTE_MIN,
    TREND_CONSUMER_NEAR_HIGH_DTE_MAX,
    TREND_CONSUMER_NEAR_HIGH_MAX_PULLBACK,
    TREND_CONSUMER_NEAR_HIGH_DTE_RISK_MULTIPLIER,
    TREND_COMMODITIES_NEAR_HIGH_MAX_PULLBACK,
    TREND_COMMODITIES_NEAR_HIGH_MAX_POSITION_PCT,
    TREND_COMMODITIES_NEAR_HIGH_RISK_MULTIPLIER,
    TREND_GOLD_NEAR_HIGH_MAX_POSITION_PCT,
    TREND_GOLD_NEAR_HIGH_TICKERS,
    RISK_ON_UNMODIFIED_RISK_MULTIPLIER,
    RISK_ON_UNMODIFIED_LOW_SCORE_MAX,
    RISK_ON_UNMODIFIED_LOW_SCORE_RISK_MULTIPLIER,
    RISK_ON_UNMODIFIED_MID_SCORE_MAX,
    RISK_ON_UNMODIFIED_MID_SCORE_RISK_MULTIPLIER,
    RISK_ON_SPY_RELATIVE_LEADER_RISK_MULTIPLIER,
    RISK_ON_SPY_RELATIVE_LEADER_MAX_POSITION_PCT,
    RS20_ENTRY_STATE_RISK_MULTIPLIER,
    CORE_CONFIRMED_QUALITY_RISK_MULTIPLIER,
    GREEN_DECEL_QUALITY_NONCONSUMER_RISK_MULTIPLIER,
    RS60_TOP_QUINTILE_RISK_MULTIPLIER,
    PRICE_VS_200MA_EXTENSION_RISK_MULTIPLIER,
    TREND_PRICE_VS_200MA_EXTENSION_RISK_MULTIPLIER,
    SIGNAL_DAY_TICKER_GREEN_RISK_MULTIPLIER,
    CLEAN_SPY_LEADER_SIGNAL_DAY_RISK_MULTIPLIER,
    CLEAN_SPY_LEADER_SIGNAL_DAY_MAX_POSITION_PCT,
    CLEAN_SPY_CAP_ONLY_LEADER_MAX_POSITION_PCT,
    CLEAN_SPY_CAP_ONLY_RS20_LEADER_MAX_POSITION_PCT,
    TREND_MID_SECTOR_DISPERSION_RISK_MULTIPLIER,
    HARD_STOP_PCT,
    ATR_STOP_MULT,
    ROUND_TRIP_COST_PCT,
    EXEC_LAG_PCT,
)
from open_position_schema import account_positions

logger = logging.getLogger(__name__)

# Earnings gap risk override for Strategy C (earnings_event_long).
# Overnight earnings gaps (±8-15%) bypass ATR stops entirely because they are
# discontinuous events — the market opens at the gap price, never trading through
# the stop.  Sizing based on the ATR stop (typically 2-3% of entry) produces
# positions 3-5× too large: a planned 1% risk becomes 3-5% actual risk.
# Using 8% as the effective risk distance brings actual earnings-gap exposure
# in line with the 1% portfolio risk target.
# The ATR stop is still displayed to the user for order-placement reference;
# only the SIZING uses this gap-risk floor.
EARNINGS_GAP_RISK_PCT   = 0.08     # 8% conservative floor for earnings-gap adverse scenario


def _apply_ticker_core_risk_multiplier(
        sig,
        sizing,
        portfolio_value,
        *,
        target_ticker,
        multiplier,
        key_prefix):
    """Apply an accepted ticker-specific core long risk scalar after sizing."""
    ticker = str(sig.get("ticker") or "").upper()
    strategy = sig.get("strategy")
    multiplier_key = f"{key_prefix}_core_risk_multiplier_applied"
    sizing[multiplier_key] = 1.0
    if (
        ticker != target_ticker
        or strategy not in {"trend_long", "breakout_long"}
        or multiplier >= 1.0
    ):
        return sizing

    old_shares = int(sizing.get("shares_to_buy") or 0)
    if old_shares <= 0:
        return sizing

    entry = float(sizing.get("entry_price") or sig.get("entry_price") or 0.0)
    if entry <= 0:
        return sizing

    new_shares = int(math.floor(old_shares * multiplier))
    if new_shares >= old_shares:
        return sizing

    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
    position_value = entry * new_shares
    risk_amount = net_risk_per_share * new_shares
    sizing[f"{key_prefix}_core_baseline_shares"] = old_shares
    sizing[f"{key_prefix}_core_new_shares"] = new_shares
    sizing["shares_to_buy"] = new_shares
    sizing["position_value_usd"] = round(position_value, 2)
    sizing["position_pct_of_portfolio"] = (
        round(position_value / portfolio_value, 4) if portfolio_value else 0.0
    )
    sizing["risk_amount_usd"] = round(risk_amount, 2)
    sizing["risk_pct"] = risk_amount / portfolio_value if portfolio_value else 0.0
    sizing[multiplier_key] = multiplier
    return sizing


def _apply_tsm_core_risk_multiplier(sig, sizing, portfolio_value):
    return _apply_ticker_core_risk_multiplier(
        sig,
        sizing,
        portfolio_value,
        target_ticker="TSM",
        multiplier=TSM_CORE_RISK_MULTIPLIER,
        key_prefix="tsm",
    )


def _apply_isrg_core_risk_multiplier(sig, sizing, portfolio_value):
    return _apply_ticker_core_risk_multiplier(
        sig,
        sizing,
        portfolio_value,
        target_ticker="ISRG",
        multiplier=ISRG_CORE_RISK_MULTIPLIER,
        key_prefix="isrg",
    )


def compute_position_size(
        portfolio_value,
        entry_price,
        stop_price,
        risk_pct=RISK_PER_TRADE_PCT,
        max_position_pct=MAX_POSITION_PCT):
    """
    Compute shares to buy using the 1% fixed-fraction risk rule.

    Formula:
        risk_amount    = portfolio_value × risk_pct
        risk_per_share = entry_price − stop_price
        shares         = floor(risk_amount / risk_per_share)   (min 1)

    Position is further capped at max_position_pct of portfolio to prevent
    oversized positions when stop is very tight (e.g. Strategy B breakout_stop).

    Returns:
        dict or None
    """
    if portfolio_value <= 0 or entry_price <= 0 or stop_price <= 0:
        return None
    if stop_price >= entry_price:
        logger.warning("stop_price >= entry_price; position size skipped")
        return None

    risk_amount    = portfolio_value * risk_pct
    risk_per_share = entry_price - stop_price
    # Include both execution cost AND exec_lag (next-day open gap) so the position
    # is sized for TRUE 1% risk.
    #
    # Previous formula:  net_risk = (entry - stop) + entry × 0.0035
    # Actual risk:       net_risk = (open  - stop) + open  × 0.0035
    #                             = (entry + gap - stop) + (entry + gap) × 0.0035
    #
    # For a $100 stock, 3% ATR, 0.5% gap:
    #   Old:  net_risk = $4.50 + $0.35 = $4.85  (1.00% of portfolio)
    #   True: net_risk = $4.50 + $0.50 + $0.35 = $5.35  (1.10% of portfolio)
    # Across 8 simultaneous positions the silent 10% overrun → 8.8% heat vs 8% cap.
    # Including EXEC_LAG_PCT brings actual risk in line with the 1% target.
    cost_per_share     = entry_price * ROUND_TRIP_COST_PCT
    gap_per_share      = entry_price * EXEC_LAG_PCT
    net_risk_per_share = risk_per_share + cost_per_share + gap_per_share
    shares             = max(1, math.floor(risk_amount / net_risk_per_share))

    # Cap at MAX_POSITION_PCT — tight stops (e.g. breakout_stop 1% below entry)
    # can produce shares that represent 50-100% of portfolio; enforce hard limit.
    max_shares     = max(1, math.floor(portfolio_value * max_position_pct / entry_price))
    if shares > max_shares:
        logger.warning(
            f"Position capped: {shares} → {max_shares} shares "
            f"({max_position_pct*100:.0f}% portfolio cap, tight stop)"
        )
        shares = max_shares

    position_value = shares * entry_price

    return {
        "portfolio_value_usd":       round(portfolio_value, 2),
        "risk_pct":                  risk_pct,
        "risk_amount_usd":           round(risk_amount, 2),
        "entry_price":               round(entry_price, 2),
        "stop_price":                round(stop_price, 2),
        "risk_per_share":            round(risk_per_share, 2),
        "net_risk_per_share":        round(net_risk_per_share, 4),
        "shares_to_buy":             shares,
        "position_value_usd":        round(position_value, 2),
        "position_pct_of_portfolio": round(position_value / portfolio_value, 4),
    }


def compute_portfolio_heat(open_positions, current_prices, portfolio_value,
                           features_dict=None):
    """
    Compute total portfolio risk exposure (portfolio heat).

    For each position:
        at_risk_usd = shares × max(0, current_price − effective_stop)

    effective_stop = highest of: hard_stop, atr_stop. Using the tighter (higher)
    of these static, entry-anchored stops reflects true current risk without
    inflating heat for positions sitting on large unrealised gains.

    NOTE (exp-20260623-020): the shipped exit is a STATIC entry stop placed as a
    resting GTC bracket and explicitly never trailed up; ATR-trailing lost in
    every window. The old trailing-from-20d-high term (high_20d × (1−TRAILING_
    STOP_PCT)) is therefore NOT part of the live stop and is deliberately
    excluded here. Including it modelled a stop the system no longer places: when
    price fell back from a 20d high the trailing level landed ABOVE current price,
    which both (a) showed a phantom "effective_stop above price" in the report and
    (b) zeroed at_risk_usd for pulled-back winners, under-reporting portfolio heat
    that gates new-position sizing. atr_stop (current_price − 1.5×ATR) is bounded
    below price and shares the live stop's 1.5×ATR basis, so it stays.

    Stop logic for hard_stop baseline:
        manual override > auto_rolling (legacy PnL > 100%) > default (avg_cost × 0.88)

    Heat cap: 8%.

    Args:
        open_positions (dict): Open positions data
        current_prices (dict): {ticker: current_close_price}
        portfolio_value (float): Total portfolio value in USD
        features_dict (dict): Optional {ticker: features} for ATR/high_20d lookups

    Returns:
        dict or None
    """
    if not open_positions or portfolio_value <= 0:
        return None

    breakdown     = []
    total_at_risk = 0.0

    for pos in account_positions(open_positions):
        ticker   = pos.get("ticker")
        shares   = pos.get("shares", 0)
        avg_cost = pos.get("avg_cost", 0)

        if not ticker or avg_cost <= 0 or shares <= 0:
            continue

        current_price      = current_prices.get(ticker, avg_cost)
        unrealized_pnl_pct = (current_price - avg_cost) / avg_cost
        legacy             = unrealized_pnl_pct > 1.0

        manual_override = pos.get("override_stop_price")
        if manual_override:
            hard_stop = manual_override
            stop_src  = "manual"
        elif legacy:
            hard_stop = current_price * (1 - HARD_STOP_PCT)
            stop_src  = "auto_rolling"
        else:
            hard_stop = avg_cost * (1 - HARD_STOP_PCT)
            stop_src  = "default"

        # Tighten to the ATR stop if features are available.
        # effective_stop = max(hard_stop, atr_stop)
        # A higher stop means less at-risk USD — more accurate for big winners.
        # The 20d-high trailing stop is intentionally NOT applied here: it is not
        # the live exit (static entry stop, exp-20260623-020) and could land above
        # current price, faking a breach and zeroing heat for pulled-back winners.
        effective_stop = hard_stop
        effective_src  = stop_src
        f = (features_dict or {}).get(ticker)
        if f:
            atr     = f.get("atr")
            if atr and atr > 0:
                atr_stop = current_price - ATR_STOP_MULT * atr
                if atr_stop > effective_stop:
                    effective_stop = round(atr_stop, 2)
                    effective_src  = "atr"

        at_risk_usd    = shares * max(0.0, current_price - effective_stop)
        total_at_risk += at_risk_usd

        breakdown.append({
            "ticker":                ticker,
            "shares":                shares,
            "current_price":         round(current_price, 2),
            "hard_stop":             round(hard_stop, 2),
            "effective_stop":        round(effective_stop, 2),
            "effective_stop_source": effective_src,
            "at_risk_usd":           round(at_risk_usd, 2),
            "at_risk_pct":           round(at_risk_usd / portfolio_value, 4),
        })

    heat_pct = total_at_risk / portfolio_value
    can_add  = heat_pct < MAX_PORTFOLIO_HEAT

    return {
        "portfolio_value_usd":   portfolio_value,
        "total_at_risk_usd":     round(total_at_risk, 2),
        "portfolio_heat_pct":    round(heat_pct, 4),
        "max_heat_pct":          MAX_PORTFOLIO_HEAT,
        "can_add_new_positions": can_add,
        "heat_note": (
            f"Heat {heat_pct*100:.1f}% {'<' if can_add else '>='} "
            f"{MAX_PORTFOLIO_HEAT*100:.0f}% cap — "
            f"{'new positions permitted' if can_add else 'NO new positions — reduce existing risk first'}"
        ),
        "position_breakdown": breakdown,
    }


def size_signals(signals, portfolio_value, risk_pct=None):
    """
    Add position_size dict to each signal.

    For earnings_event_long signals, position sizing uses the LARGER of:
      (a) ATR-based stop distance (entry − stop_price), or
      (b) EARNINGS_GAP_RISK_PCT × entry_price  (conservative gap risk floor)

    Earnings overnight gaps (±8-15%) are discontinuous events that bypass ATR
    stops entirely.  Sizing off a 2-3% ATR stop when the true loss scenario is
    an 8-15% gap produces positions 3-5× larger than the 1% risk target.
    The effective_stop_for_sizing field documents the adjusted level; the
    signal's stop_price (ATR-based) is preserved for actual order placement.

    Args:
        signals         (list[dict]): Enriched signals with stop_price
        portfolio_value (float):      Total portfolio value
        risk_pct        (float|None): Override risk per trade (default: RISK_PER_TRADE_PCT=1%).
                                      Pass 0.0075 for NEUTRAL, 0.005 for BEAR_SHALLOW.
    Returns:
        list[dict]: Signals with 'sizing' field added
    """
    def _zero_risk_sizing(base_risk_pct, entry_price, stop_price):
        return {
            "portfolio_value_usd": round(portfolio_value, 2),
            "risk_pct": 0.0,
            "risk_amount_usd": 0.0,
            "entry_price": round(entry_price, 2),
            "stop_price": round(stop_price, 2),
            "risk_per_share": round(entry_price - stop_price, 2),
            "net_risk_per_share": round(
                (entry_price - stop_price)
                + entry_price * ROUND_TRIP_COST_PCT
                + entry_price * EXEC_LAG_PCT,
                4,
            ),
            "shares_to_buy": 0,
            "position_value_usd": 0.0,
            "position_pct_of_portfolio": 0.0,
            "base_risk_pct": base_risk_pct,
        }

    effective_risk_pct = risk_pct if risk_pct is not None else RISK_PER_TRADE_PCT
    sized = []
    for sig in signals:
        entry    = sig.get("entry_price")
        stop     = sig.get("stop_price")
        strategy = sig.get("strategy", "")
        ticker = str(sig.get("ticker") or "").upper()
        if entry and stop and portfolio_value:
            signal_risk_pct = effective_risk_pct
            trade_quality_score = sig.get("trade_quality_score")
            sector = sig.get("sector")
            gap_vulnerability_pct = sig.get("gap_vulnerability_pct")
            days_to_earnings = sig.get("days_to_earnings")
            is_low_tqs = (
                trade_quality_score is not None
                and trade_quality_score < LOW_TQS_RISK_THRESHOLD
            )
            is_breakout_non_exempt = (
                strategy == "breakout_long"
                and sector not in LOW_TQS_HAIRCUT_EXEMPT_SECTORS
            )
            tqs_de_risk_applied = (
                is_low_tqs
                and sector not in LOW_TQS_HAIRCUT_EXEMPT_SECTORS
            )
            tqs_risk_multiplier = 1.0
            if tqs_de_risk_applied:
                if is_breakout_non_exempt:
                    tqs_risk_multiplier = LOW_TQS_BREAKOUT_NON_EXEMPT_RISK_MULTIPLIER
                else:
                    tqs_risk_multiplier = LOW_TQS_RISK_MULTIPLIER
                signal_risk_pct *= tqs_risk_multiplier
            trend_industrials_risk_multiplier = 1.0
            if strategy == "trend_long" and sector == "Industrials":
                trend_industrials_risk_multiplier = TREND_INDUSTRIALS_RISK_MULTIPLIER
                signal_risk_pct *= trend_industrials_risk_multiplier
            trend_financials_risk_multiplier = 1.0
            financials_sector_leader_risk_multiplier = 1.0
            risk_on_unmodified_risk_multiplier = 1.0
            spy_relative_leader_risk_on_multiplier = 1.0
            trend_mid_sector_dispersion_risk_multiplier = 1.0
            rs20_entry_state_risk_multiplier = 1.0
            core_confirmed_quality_risk_multiplier = 1.0
            green_decel_quality_nonconsumer_risk_multiplier = 1.0
            signal_day_ticker_green_risk_multiplier = 1.0
            rs60_top_quintile_risk_multiplier = 1.0
            price_vs_200ma_extension_risk_multiplier = 1.0
            trend_price_vs_200ma_extension_risk_multiplier = 1.0
            clean_spy_leader_signal_day_risk_multiplier = 1.0
            trend_tech_tight_gap_risk_multiplier = 1.0
            if (
                strategy == "trend_long"
                and sector == "Technology"
                and gap_vulnerability_pct is not None
                and TREND_TECH_TIGHT_GAP_VULN_MIN <= gap_vulnerability_pct < TREND_TECH_TIGHT_GAP_VULN_MAX
            ):
                # Residual audit found this tighter-gap pocket was a stable drag
                # in the weaker windows and absent in the dominant strong tape.
                trend_tech_tight_gap_risk_multiplier = (
                    TREND_TECH_TIGHT_GAP_RISK_MULTIPLIER
                )
                signal_risk_pct *= trend_tech_tight_gap_risk_multiplier
            trend_tech_gap_risk_multiplier = 1.0
            if (
                strategy == "trend_long"
                and sector == "Technology"
                and gap_vulnerability_pct is not None
                and TREND_TECH_GAP_VULN_MIN <= gap_vulnerability_pct < TREND_TECH_GAP_VULN_MAX
            ):
                # Accepted cohort rule: this pocket was too fragile for full size,
                # but a full ban (0x) proved worse than keeping a small 0.25x stake.
                trend_tech_gap_risk_multiplier = TREND_TECH_GAP_RISK_MULTIPLIER
                signal_risk_pct *= trend_tech_gap_risk_multiplier
            trend_tech_near_high_risk_multiplier = 1.0
            pct_from_52w_high = (sig.get("conditions_met") or {}).get("pct_from_52w_high")
            if strategy == "trend_long" and sector == "Financials":
                trend_financials_risk_multiplier = TREND_FINANCIALS_RISK_MULTIPLIER
                signal_risk_pct *= trend_financials_risk_multiplier
                if sig.get("financials_sector_leader") is True:
                    financials_sector_leader_risk_multiplier = (
                        TREND_FINANCIALS_SECTOR_LEADER_RISK_MULTIPLIER
                        / TREND_FINANCIALS_RISK_MULTIPLIER
                    )
                    signal_risk_pct *= financials_sector_leader_risk_multiplier
            if (
                strategy == "trend_long"
                and sector == "Technology"
                and pct_from_52w_high is not None
                and pct_from_52w_high >= TREND_TECH_NEAR_HIGH_MAX_PULLBACK
            ):
                # Residual trend-Tech drag is concentrated in the near-high entry
                # shape after the accepted stack; keep the pocket tradable, but
                # only at 25% size so deeper-pullback winners still get budget.
                trend_tech_near_high_risk_multiplier = (
                    TREND_TECH_NEAR_HIGH_RISK_MULTIPLIER
                )
                signal_risk_pct *= trend_tech_near_high_risk_multiplier
            trend_tech_dte_risk_multiplier = 1.0
            if (
                strategy == "trend_long"
                and sector == "Technology"
                and days_to_earnings is not None
                and TREND_TECH_DTE_MIN <= days_to_earnings <= TREND_TECH_DTE_MAX
            ):
                # This is the surviving Technology trend DTE sleeve after the
                # rejected 59-69 DTE+gap probe; keep it narrow and partial-size.
                trend_tech_dte_risk_multiplier = TREND_TECH_DTE_RISK_MULTIPLIER
                signal_risk_pct *= trend_tech_dte_risk_multiplier
            breakout_industrials_gap_risk_multiplier = 1.0
            if (
                strategy == "breakout_long"
                and sector == "Industrials"
                and gap_vulnerability_pct is not None
                and BREAKOUT_INDUSTRIALS_GAP_VULN_MIN <= gap_vulnerability_pct < BREAKOUT_INDUSTRIALS_GAP_VULN_MAX
            ):
                breakout_industrials_gap_risk_multiplier = (
                    BREAKOUT_INDUSTRIALS_GAP_RISK_MULTIPLIER
                )
                signal_risk_pct *= breakout_industrials_gap_risk_multiplier
            breakout_comms_near_high_risk_multiplier = 1.0
            if (
                strategy == "breakout_long"
                and sector == "Communication Services"
                and pct_from_52w_high is not None
                and pct_from_52w_high >= BREAKOUT_COMMS_NEAR_HIGH_MAX_PULLBACK
            ):
                # Residual breakout audit found the weak-window leak here was an
                # entry shape, not another sector+gap pocket. Keep the sleeve
                # live, but only at 25% risk so stronger breakout cohorts still
                # dominate slot usage.
                breakout_comms_near_high_risk_multiplier = (
                    BREAKOUT_COMMS_NEAR_HIGH_RISK_MULTIPLIER
                )
                signal_risk_pct *= breakout_comms_near_high_risk_multiplier
            breakout_comms_gap_risk_multiplier = 1.0
            if (
                strategy == "breakout_long"
                and sector == "Communication Services"
                and gap_vulnerability_pct is not None
                and BREAKOUT_COMMS_GAP_VULN_MIN <= gap_vulnerability_pct < BREAKOUT_COMMS_GAP_VULN_MAX
            ):
                # After the accepted near-high haircut, the residual drag in
                # this sleeve still clustered in moderate-gap setups.
                breakout_comms_gap_risk_multiplier = (
                    BREAKOUT_COMMS_GAP_RISK_MULTIPLIER
                )
                signal_risk_pct *= breakout_comms_gap_risk_multiplier
            breakout_financials_dte_risk_multiplier = 1.0
            if (
                strategy == "breakout_long"
                and sector == "Financials"
                and days_to_earnings is not None
                and BREAKOUT_FINANCIALS_DTE_MIN <= days_to_earnings <= BREAKOUT_FINANCIALS_DTE_MAX
            ):
                # Residual breakout audit found that the remaining Financials drag
                # was event-proximity, not another sector-only or price-shape leak.
                breakout_financials_dte_risk_multiplier = (
                    BREAKOUT_FINANCIALS_DTE_RISK_MULTIPLIER
                )
                signal_risk_pct *= breakout_financials_dte_risk_multiplier
            breakout_tech_dte_risk_multiplier = 1.0
            if (
                strategy == "breakout_long"
                and sector == "Technology"
                and days_to_earnings is not None
                and BREAKOUT_TECH_DTE_MIN <= days_to_earnings <= BREAKOUT_TECH_DTE_MAX
            ):
                # Residual audit found this breakout-only Technology pocket was
                # repeatedly weak 26-40 trading days before earnings and absent
                # from the dominant strong tape. This is not the rejected trend
                # Technology DTE+gap family.
                breakout_tech_dte_risk_multiplier = (
                    BREAKOUT_TECH_DTE_RISK_MULTIPLIER
                )
                signal_risk_pct *= breakout_tech_dte_risk_multiplier
            breakout_healthcare_dte_risk_multiplier = 1.0
            if (
                strategy == "breakout_long"
                and sector == "Healthcare"
                and days_to_earnings is not None
                and BREAKOUT_HEALTHCARE_DTE_MIN <= days_to_earnings <= BREAKOUT_HEALTHCARE_DTE_MAX
            ):
                # Runtime residual audit found this Healthcare breakout
                # event-distance sleeve improved the mid/old validation windows.
                # Keep it partial-size; widening to 20-70 DTE cut a late winner.
                breakout_healthcare_dte_risk_multiplier = (
                    BREAKOUT_HEALTHCARE_DTE_RISK_MULTIPLIER
                )
                signal_risk_pct *= breakout_healthcare_dte_risk_multiplier
            trend_healthcare_dte_risk_multiplier = 1.0
            if (
                strategy == "trend_long"
                and sector == "Healthcare"
                and days_to_earnings is not None
                and TREND_HEALTHCARE_DTE_MIN <= days_to_earnings <= TREND_HEALTHCARE_DTE_MAX
            ):
                # Residual trend audit found a wider pre-earnings Healthcare
                # pocket that is outside the hard dte<=3 entry block but still
                # carried unstable event-risk exposure.
                trend_healthcare_dte_risk_multiplier = (
                    TREND_HEALTHCARE_DTE_RISK_MULTIPLIER
                )
                signal_risk_pct *= trend_healthcare_dte_risk_multiplier
            trend_consumer_near_high_dte_risk_multiplier = 1.0
            if (
                strategy == "trend_long"
                and sector == "Consumer Discretionary"
                and days_to_earnings is not None
                and pct_from_52w_high is not None
                and TREND_CONSUMER_NEAR_HIGH_DTE_MIN <= days_to_earnings <= TREND_CONSUMER_NEAR_HIGH_DTE_MAX
                and pct_from_52w_high >= TREND_CONSUMER_NEAR_HIGH_MAX_PULLBACK
            ):
                # Fixed-window residual audit found this MCD-like pocket was a
                # repeat loser and absent from the mid-window winners. Keep the
                # rule narrow: trend only, sector only, near-high only, 30-65 DTE.
                trend_consumer_near_high_dte_risk_multiplier = (
                    TREND_CONSUMER_NEAR_HIGH_DTE_RISK_MULTIPLIER
                )
                signal_risk_pct *= trend_consumer_near_high_dte_risk_multiplier
            trend_commodities_near_high_risk_multiplier = 1.0
            if (
                strategy == "trend_long"
                and sector == "Commodities"
                and pct_from_52w_high is not None
                and pct_from_52w_high >= TREND_COMMODITIES_NEAR_HIGH_MAX_PULLBACK
            ):
                # Commodity trend winners were concentrated near 52-week highs.
                # Keep this as an allocation boost, not a new entry source.
                trend_commodities_near_high_risk_multiplier = (
                    TREND_COMMODITIES_NEAR_HIGH_RISK_MULTIPLIER
                )
                signal_risk_pct *= trend_commodities_near_high_risk_multiplier
            existing_sizing_multipliers = (
                tqs_risk_multiplier,
                trend_industrials_risk_multiplier,
                trend_financials_risk_multiplier,
                financials_sector_leader_risk_multiplier,
                trend_tech_tight_gap_risk_multiplier,
                trend_tech_gap_risk_multiplier,
                trend_tech_near_high_risk_multiplier,
                trend_tech_dte_risk_multiplier,
                breakout_industrials_gap_risk_multiplier,
                breakout_comms_near_high_risk_multiplier,
                breakout_comms_gap_risk_multiplier,
                breakout_financials_dte_risk_multiplier,
                breakout_tech_dte_risk_multiplier,
                breakout_healthcare_dte_risk_multiplier,
                trend_healthcare_dte_risk_multiplier,
                trend_consumer_near_high_dte_risk_multiplier,
                trend_commodities_near_high_risk_multiplier,
            )
            has_other_sizing_rule = any(
                multiplier != 1.0 for multiplier in existing_sizing_multipliers
            )
            if (
                sig.get("regime_exit_bucket") == "risk_on"
                and not has_other_sizing_rule
            ):
                if sig.get("spy_relative_leader") is True:
                    risk_on_unmodified_risk_multiplier = (
                        RISK_ON_SPY_RELATIVE_LEADER_RISK_MULTIPLIER
                    )
                    spy_relative_leader_risk_on_multiplier = (
                        RISK_ON_SPY_RELATIVE_LEADER_RISK_MULTIPLIER
                    )
                else:
                    regime_exit_score = sig.get("regime_exit_score")
                    if (
                        regime_exit_score is not None
                        and regime_exit_score < RISK_ON_UNMODIFIED_LOW_SCORE_MAX
                    ):
                        risk_on_unmodified_risk_multiplier = (
                            RISK_ON_UNMODIFIED_LOW_SCORE_RISK_MULTIPLIER
                        )
                    elif (
                        regime_exit_score is not None
                        and regime_exit_score < RISK_ON_UNMODIFIED_MID_SCORE_MAX
                    ):
                        risk_on_unmodified_risk_multiplier = (
                            RISK_ON_UNMODIFIED_MID_SCORE_RISK_MULTIPLIER
                        )
                    else:
                        risk_on_unmodified_risk_multiplier = (
                            RISK_ON_UNMODIFIED_RISK_MULTIPLIER
                        )
                signal_risk_pct *= risk_on_unmodified_risk_multiplier
            max_position_pct = MAX_POSITION_PCT
            if (
                spy_relative_leader_risk_on_multiplier
                == RISK_ON_SPY_RELATIVE_LEADER_RISK_MULTIPLIER
            ):
                max_position_pct = RISK_ON_SPY_RELATIVE_LEADER_MAX_POSITION_PCT
            clean_spy_leader_signal_day_cap_applied = False
            clean_spy_cap_only_leader_cap_applied = False
            clean_spy_cap_only_rs20_leader_cap_applied = False
            breakout_commodities_cap_applied = False
            financials_mid_dispersion_leader_cap_applied = False
            trend_gold_near_high_cap_applied = False
            if (
                sig.get("signal_day_ticker_outperformed_spy") is True
                and strategy in {"trend_long", "breakout_long"}
                and spy_relative_leader_risk_on_multiplier
                == RISK_ON_SPY_RELATIVE_LEADER_RISK_MULTIPLIER
            ):
                clean_spy_leader_signal_day_cap_applied = True
                max_position_pct = max(
                    max_position_pct,
                    CLEAN_SPY_LEADER_SIGNAL_DAY_MAX_POSITION_PCT,
                )
            if strategy == "breakout_long" and sector == "Commodities":
                breakout_commodities_cap_applied = True
                max_position_pct = max(
                    max_position_pct,
                    BREAKOUT_COMMODITIES_MAX_POSITION_PCT,
                )
            if (
                trend_commodities_near_high_risk_multiplier
                == TREND_COMMODITIES_NEAR_HIGH_RISK_MULTIPLIER
            ):
                max_position_pct = max(
                    max_position_pct,
                    TREND_COMMODITIES_NEAR_HIGH_MAX_POSITION_PCT,
                )
                if ticker in TREND_GOLD_NEAR_HIGH_TICKERS:
                    trend_gold_near_high_cap_applied = True
                    max_position_pct = max(
                        max_position_pct,
                        TREND_GOLD_NEAR_HIGH_MAX_POSITION_PCT,
                    )
            if financials_sector_leader_risk_multiplier != 1.0:
                max_position_pct = max(
                    max_position_pct,
                    TREND_FINANCIALS_SECTOR_LEADER_MAX_POSITION_PCT,
                )
                if sig.get("mid_sector_dispersion") is True:
                    financials_mid_dispersion_leader_cap_applied = True
                    max_position_pct = max(
                        max_position_pct,
                        TREND_FINANCIALS_MID_DISPERSION_LEADER_MAX_POSITION_PCT,
                    )
            if (
                strategy == "trend_long"
                and sig.get("mid_sector_dispersion") is True
            ):
                trend_mid_sector_dispersion_risk_multiplier = (
                    TREND_MID_SECTOR_DISPERSION_RISK_MULTIPLIER
                )
                signal_risk_pct *= trend_mid_sector_dispersion_risk_multiplier

            if signal_risk_pct <= 0:
                sizing = _zero_risk_sizing(effective_risk_pct, entry, stop)
            elif strategy == "earnings_event_long":
                # Gap risk dominates: size based on max(ATR stop dist, 8% gap risk).
                # For typical ATR ≤ 5%: gap_risk = 8% > ATR stop ≤ 7.5% → gap floor applies.
                # For ATR = 5% (near the 5% gate): max(7.5%, 8%) = 8% — gap floor applies.
                # This reduces earnings position sizes by ~60-75% vs ATR-only sizing.
                atr_risk  = entry - stop
                gap_risk  = entry * EARNINGS_GAP_RISK_PCT
                effective_stop = round(entry - max(atr_risk, gap_risk), 2)
                sizing = compute_position_size(
                    portfolio_value,
                    entry,
                    effective_stop,
                    risk_pct=signal_risk_pct,
                    max_position_pct=max_position_pct,
                )
                if sizing:
                    sizing["earnings_gap_risk_applied"]  = True
                    sizing["gap_risk_pct"]               = EARNINGS_GAP_RISK_PCT
                    sizing["effective_stop_for_sizing"]  = effective_stop
            else:
                sizing = compute_position_size(
                    portfolio_value,
                    entry,
                    stop,
                    risk_pct=signal_risk_pct,
                    max_position_pct=max_position_pct,
                )
            if sizing:
                if (
                    sig.get("rs20_entry_state_leader") is True
                    and strategy in {"trend_long", "breakout_long"}
                    and signal_risk_pct > 0
                    and RS20_ENTRY_STATE_RISK_MULTIPLIER > 1.0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    cap_shares = int(
                        math.floor(portfolio_value * max_position_pct / entry)
                    )
                    desired_shares = max(
                        old_shares,
                        int(math.floor(old_shares * RS20_ENTRY_STATE_RISK_MULTIPLIER)),
                    )
                    new_shares = min(desired_shares, cap_shares)
                    if new_shares > old_shares:
                        net_risk_per_share = sizing.get("net_risk_per_share") or 0.0
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        rs20_entry_state_risk_multiplier = (
                            RS20_ENTRY_STATE_RISK_MULTIPLIER
                        )
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing["rs20_entry_state_baseline_shares"] = old_shares
                        sizing["rs20_entry_state_desired_shares"] = desired_shares
                        sizing["rs20_entry_state_cap_shares"] = cap_shares
                if (
                    sig.get("signal_day_ticker_green_candle") is True
                    and strategy in {"trend_long", "breakout_long"}
                    and sizing.get("shares_to_buy")
                    and signal_risk_pct > 0
                    and SIGNAL_DAY_TICKER_GREEN_RISK_MULTIPLIER > 1.0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    cap_shares = int(
                        math.floor(portfolio_value * max_position_pct / entry)
                    )
                    desired_shares = max(
                        old_shares,
                        int(math.floor(old_shares * SIGNAL_DAY_TICKER_GREEN_RISK_MULTIPLIER)),
                    )
                    new_shares = min(desired_shares, cap_shares)
                    if new_shares > old_shares:
                        net_risk_per_share = sizing.get("net_risk_per_share") or 0.0
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        signal_day_ticker_green_risk_multiplier = (
                            SIGNAL_DAY_TICKER_GREEN_RISK_MULTIPLIER
                        )
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing["signal_day_ticker_green_baseline_shares"] = old_shares
                        sizing["signal_day_ticker_green_desired_shares"] = desired_shares
                        sizing["signal_day_ticker_green_cap_shares"] = cap_shares
                if (
                    sig.get("rs60_top_quintile_state") is True
                    and strategy in {"trend_long", "breakout_long"}
                    and sizing.get("shares_to_buy")
                    and signal_risk_pct > 0
                    and RS60_TOP_QUINTILE_RISK_MULTIPLIER > 1.0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    cap_shares = int(
                        math.floor(portfolio_value * max_position_pct / entry)
                    )
                    desired_shares = max(
                        old_shares,
                        int(math.floor(old_shares * RS60_TOP_QUINTILE_RISK_MULTIPLIER)),
                    )
                    new_shares = min(desired_shares, cap_shares)
                    if new_shares > old_shares:
                        net_risk_per_share = sizing.get("net_risk_per_share") or 0.0
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        rs60_top_quintile_risk_multiplier = (
                            RS60_TOP_QUINTILE_RISK_MULTIPLIER
                        )
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing["rs60_top_quintile_baseline_shares"] = old_shares
                        sizing["rs60_top_quintile_desired_shares"] = desired_shares
                        sizing["rs60_top_quintile_cap_shares"] = cap_shares
                        sizing["rs60_top_quintile_new_shares"] = new_shares
                if (
                    sig.get("signal_day_ticker_outperformed_spy") is True
                    and strategy in {"trend_long", "breakout_long"}
                    and sizing.get("shares_to_buy")
                    and signal_risk_pct > 0
                    and spy_relative_leader_risk_on_multiplier
                    == RISK_ON_SPY_RELATIVE_LEADER_RISK_MULTIPLIER
                    and CLEAN_SPY_LEADER_SIGNAL_DAY_RISK_MULTIPLIER > 1.0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    cap_shares = int(
                        math.floor(portfolio_value * max_position_pct / entry)
                    )
                    desired_shares = max(
                        old_shares,
                        int(
                            math.floor(
                                old_shares
                                * CLEAN_SPY_LEADER_SIGNAL_DAY_RISK_MULTIPLIER
                            )
                        ),
                    )
                    new_shares = min(desired_shares, cap_shares)
                    if new_shares > old_shares:
                        net_risk_per_share = sizing.get("net_risk_per_share") or 0.0
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        clean_spy_leader_signal_day_risk_multiplier = (
                            CLEAN_SPY_LEADER_SIGNAL_DAY_RISK_MULTIPLIER
                        )
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing["clean_spy_leader_signal_day_baseline_shares"] = (
                            old_shares
                        )
                        sizing["clean_spy_leader_signal_day_desired_shares"] = (
                            desired_shares
                        )
                        sizing["clean_spy_leader_signal_day_cap_shares"] = cap_shares
                        sizing["clean_spy_leader_signal_day_new_shares"] = new_shares
                if (
                    trend_gold_near_high_cap_applied
                    and sizing.get("shares_to_buy")
                    and sizing.get("net_risk_per_share")
                    and signal_risk_pct > 0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
                    pre_sizing_risk_pct = effective_risk_pct
                    for multiplier in (
                        tqs_risk_multiplier,
                        risk_on_unmodified_risk_multiplier,
                        spy_relative_leader_risk_on_multiplier,
                        rs20_entry_state_risk_multiplier,
                        signal_day_ticker_green_risk_multiplier,
                        rs60_top_quintile_risk_multiplier,
                        clean_spy_leader_signal_day_risk_multiplier,
                        trend_mid_sector_dispersion_risk_multiplier,
                        trend_commodities_near_high_risk_multiplier,
                    ):
                        pre_sizing_risk_pct *= multiplier
                    raw_shares = max(
                        1,
                        int(
                            math.floor(
                                (portfolio_value * pre_sizing_risk_pct)
                                / net_risk_per_share
                            )
                        ),
                    )
                    old_cap_shares = max(
                        1,
                        int(
                            math.floor(
                                portfolio_value
                                * TREND_COMMODITIES_NEAR_HIGH_MAX_POSITION_PCT
                                / entry
                            )
                        ),
                    )
                    new_cap_shares = max(
                        1,
                        int(
                            math.floor(
                                portfolio_value
                                * TREND_GOLD_NEAR_HIGH_MAX_POSITION_PCT
                                / entry
                            )
                        ),
                    )
                    new_shares = min(raw_shares, new_cap_shares)
                    if new_shares > old_shares:
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing["trend_gold_near_high_cap_baseline_shares"] = (
                            old_shares
                        )
                        sizing["trend_gold_near_high_cap_raw_shares"] = raw_shares
                        sizing["trend_gold_near_high_cap_old_cap_shares"] = (
                            old_cap_shares
                        )
                        sizing["trend_gold_near_high_cap_new_cap_shares"] = (
                            new_cap_shares
                        )
                        sizing["trend_gold_near_high_cap_new_shares"] = new_shares
                if (
                    clean_spy_leader_signal_day_cap_applied
                    and clean_spy_leader_signal_day_risk_multiplier <= 1.0
                    and sizing.get("shares_to_buy")
                    and sizing.get("net_risk_per_share")
                    and signal_risk_pct > 0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
                    old_cap_pct = float(max_position_pct)
                    new_cap_pct = max(
                        old_cap_pct,
                        CLEAN_SPY_CAP_ONLY_LEADER_MAX_POSITION_PCT,
                    )
                    if new_cap_pct > old_cap_pct:
                        pre_sizing_risk_pct = effective_risk_pct
                        for multiplier in (
                            tqs_risk_multiplier,
                            trend_industrials_risk_multiplier,
                            trend_financials_risk_multiplier,
                            financials_sector_leader_risk_multiplier,
                            risk_on_unmodified_risk_multiplier,
                            spy_relative_leader_risk_on_multiplier,
                            trend_mid_sector_dispersion_risk_multiplier,
                            trend_tech_tight_gap_risk_multiplier,
                            trend_tech_gap_risk_multiplier,
                            trend_tech_near_high_risk_multiplier,
                            trend_tech_dte_risk_multiplier,
                            breakout_industrials_gap_risk_multiplier,
                            breakout_comms_near_high_risk_multiplier,
                            breakout_comms_gap_risk_multiplier,
                            breakout_financials_dte_risk_multiplier,
                            breakout_tech_dte_risk_multiplier,
                            breakout_healthcare_dte_risk_multiplier,
                            trend_healthcare_dte_risk_multiplier,
                            trend_consumer_near_high_dte_risk_multiplier,
                            trend_commodities_near_high_risk_multiplier,
                        ):
                            pre_sizing_risk_pct *= multiplier
                        raw_shares = max(
                            1,
                            int(
                                math.floor(
                                    (portfolio_value * pre_sizing_risk_pct)
                                    / net_risk_per_share
                                )
                            ),
                        )
                        old_cap_shares = max(
                            1,
                            int(math.floor(portfolio_value * old_cap_pct / entry)),
                        )
                        new_cap_shares = max(
                            1,
                            int(math.floor(portfolio_value * new_cap_pct / entry)),
                        )
                        new_shares = min(raw_shares, new_cap_shares)
                        if new_shares > old_shares:
                            risk_amount = new_shares * net_risk_per_share
                            position_value = new_shares * entry
                            sizing["shares_to_buy"] = new_shares
                            sizing["position_value_usd"] = round(position_value, 2)
                            sizing["position_pct_of_portfolio"] = round(
                                position_value / portfolio_value,
                                4,
                            )
                            sizing["risk_amount_usd"] = round(risk_amount, 2)
                            sizing["risk_pct"] = (
                                risk_amount / portfolio_value
                                if portfolio_value
                                else 0.0
                            )
                            sizing[
                                "clean_spy_cap_only_leader_cap_baseline_shares"
                            ] = old_shares
                            sizing[
                                "clean_spy_cap_only_leader_cap_raw_shares"
                            ] = raw_shares
                            sizing[
                                "clean_spy_cap_only_leader_cap_old_cap_pct"
                            ] = old_cap_pct
                            sizing[
                                "clean_spy_cap_only_leader_cap_new_cap_pct"
                            ] = new_cap_pct
                            sizing[
                                "clean_spy_cap_only_leader_cap_old_cap_shares"
                            ] = old_cap_shares
                            sizing[
                                "clean_spy_cap_only_leader_cap_new_cap_shares"
                            ] = new_cap_shares
                            sizing[
                                "clean_spy_cap_only_leader_cap_new_shares"
                            ] = new_shares
                            sizing["max_position_pct_applied"] = new_cap_pct
                            clean_spy_cap_only_leader_cap_applied = True
                if (
                    clean_spy_cap_only_leader_cap_applied
                    and sig.get("rs20_entry_state_leader") is True
                    and sizing.get("shares_to_buy")
                    and sizing.get("net_risk_per_share")
                    and signal_risk_pct > 0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
                    old_cap_pct = float(sizing.get("max_position_pct_applied") or max_position_pct)
                    new_cap_pct = max(
                        old_cap_pct,
                        CLEAN_SPY_CAP_ONLY_RS20_LEADER_MAX_POSITION_PCT,
                    )
                    if new_cap_pct > old_cap_pct:
                        pre_sizing_risk_pct = effective_risk_pct
                        for multiplier in (
                            tqs_risk_multiplier,
                            trend_industrials_risk_multiplier,
                            trend_financials_risk_multiplier,
                            financials_sector_leader_risk_multiplier,
                            risk_on_unmodified_risk_multiplier,
                            spy_relative_leader_risk_on_multiplier,
                            trend_mid_sector_dispersion_risk_multiplier,
                            trend_tech_tight_gap_risk_multiplier,
                            trend_tech_gap_risk_multiplier,
                            trend_tech_near_high_risk_multiplier,
                            trend_tech_dte_risk_multiplier,
                            breakout_industrials_gap_risk_multiplier,
                            breakout_comms_near_high_risk_multiplier,
                            breakout_comms_gap_risk_multiplier,
                            breakout_financials_dte_risk_multiplier,
                            breakout_tech_dte_risk_multiplier,
                            breakout_healthcare_dte_risk_multiplier,
                            trend_healthcare_dte_risk_multiplier,
                            trend_consumer_near_high_dte_risk_multiplier,
                            trend_commodities_near_high_risk_multiplier,
                        ):
                            pre_sizing_risk_pct *= multiplier
                        raw_shares = max(
                            1,
                            int(
                                math.floor(
                                    (portfolio_value * pre_sizing_risk_pct)
                                    / net_risk_per_share
                                )
                            ),
                        )
                        old_cap_shares = max(
                            1,
                            int(math.floor(portfolio_value * old_cap_pct / entry)),
                        )
                        new_cap_shares = max(
                            1,
                            int(math.floor(portfolio_value * new_cap_pct / entry)),
                        )
                        new_shares = min(raw_shares, new_cap_shares)
                        if new_shares > old_shares:
                            risk_amount = new_shares * net_risk_per_share
                            position_value = new_shares * entry
                            sizing["shares_to_buy"] = new_shares
                            sizing["position_value_usd"] = round(position_value, 2)
                            sizing["position_pct_of_portfolio"] = round(
                                position_value / portfolio_value,
                                4,
                            )
                            sizing["risk_amount_usd"] = round(risk_amount, 2)
                            sizing["risk_pct"] = (
                                risk_amount / portfolio_value
                                if portfolio_value
                                else 0.0
                            )
                            sizing[
                                "clean_spy_cap_only_rs20_cap_baseline_shares"
                            ] = old_shares
                            sizing[
                                "clean_spy_cap_only_rs20_cap_raw_shares"
                            ] = raw_shares
                            sizing[
                                "clean_spy_cap_only_rs20_cap_old_cap_pct"
                            ] = old_cap_pct
                            sizing[
                                "clean_spy_cap_only_rs20_cap_new_cap_pct"
                            ] = new_cap_pct
                            sizing[
                                "clean_spy_cap_only_rs20_cap_old_cap_shares"
                            ] = old_cap_shares
                            sizing[
                                "clean_spy_cap_only_rs20_cap_new_cap_shares"
                            ] = new_cap_shares
                            sizing[
                                "clean_spy_cap_only_rs20_cap_new_shares"
                            ] = new_shares
                            sizing["max_position_pct_applied"] = new_cap_pct
                            clean_spy_cap_only_rs20_leader_cap_applied = True
                if (
                    sig.get("price_vs_200ma_extension_state") is True
                    and strategy in {"trend_long", "breakout_long"}
                    and sizing.get("shares_to_buy")
                    and sizing.get("net_risk_per_share")
                    and signal_risk_pct > 0
                    and PRICE_VS_200MA_EXTENSION_RISK_MULTIPLIER > 1.0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
                    cap_pct = float(
                        sizing.get("max_position_pct_applied") or max_position_pct
                    )
                    cap_shares = int(math.floor(portfolio_value * cap_pct / entry))
                    desired_shares = max(
                        old_shares,
                        int(
                            math.floor(
                                old_shares * PRICE_VS_200MA_EXTENSION_RISK_MULTIPLIER
                            )
                        ),
                    )
                    new_shares = min(desired_shares, cap_shares)
                    if new_shares > old_shares:
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        price_vs_200ma_extension_risk_multiplier = (
                            PRICE_VS_200MA_EXTENSION_RISK_MULTIPLIER
                        )
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing["price_vs_200ma_extension_baseline_shares"] = old_shares
                        sizing["price_vs_200ma_extension_desired_shares"] = (
                            desired_shares
                        )
                        sizing["price_vs_200ma_extension_cap_shares"] = cap_shares
                        sizing["price_vs_200ma_extension_new_shares"] = new_shares
                if (
                    sig.get("price_vs_200ma_extension_state") is True
                    and strategy == "trend_long"
                    and sector not in {"ETF", "Commodities"}
                    and sizing.get("shares_to_buy")
                    and sizing.get("net_risk_per_share")
                    and signal_risk_pct > 0
                    and TREND_PRICE_VS_200MA_EXTENSION_RISK_MULTIPLIER > 1.0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
                    cap_pct = float(
                        sizing.get("max_position_pct_applied") or max_position_pct
                    )
                    cap_shares = int(math.floor(portfolio_value * cap_pct / entry))
                    desired_shares = max(
                        old_shares,
                        int(
                            math.floor(
                                old_shares
                                * TREND_PRICE_VS_200MA_EXTENSION_RISK_MULTIPLIER
                            )
                        ),
                    )
                    new_shares = min(desired_shares, cap_shares)
                    if new_shares > old_shares:
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        trend_price_vs_200ma_extension_risk_multiplier = (
                            TREND_PRICE_VS_200MA_EXTENSION_RISK_MULTIPLIER
                        )
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing[
                            "trend_price_vs_200ma_extension_baseline_shares"
                        ] = old_shares
                        sizing[
                            "trend_price_vs_200ma_extension_desired_shares"
                        ] = desired_shares
                        sizing[
                            "trend_price_vs_200ma_extension_cap_shares"
                        ] = cap_shares
                        sizing[
                            "trend_price_vs_200ma_extension_new_shares"
                        ] = new_shares
                if (
                    sig.get("core_confirmed_quality_state") is True
                    and strategy in {"trend_long", "breakout_long"}
                    and sizing.get("shares_to_buy")
                    and sizing.get("net_risk_per_share")
                    and signal_risk_pct > 0
                    and CORE_CONFIRMED_QUALITY_RISK_MULTIPLIER > 1.0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
                    cap_pct = float(
                        sizing.get("max_position_pct_applied") or max_position_pct
                    )
                    cap_shares = int(math.floor(portfolio_value * cap_pct / entry))
                    desired_shares = max(
                        old_shares,
                        int(
                            math.floor(
                                old_shares
                                * CORE_CONFIRMED_QUALITY_RISK_MULTIPLIER
                            )
                        ),
                    )
                    new_shares = min(desired_shares, cap_shares)
                    if new_shares > old_shares:
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        core_confirmed_quality_risk_multiplier = (
                            CORE_CONFIRMED_QUALITY_RISK_MULTIPLIER
                        )
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing["core_confirmed_quality_baseline_shares"] = old_shares
                        sizing["core_confirmed_quality_desired_shares"] = (
                            desired_shares
                        )
                        sizing["core_confirmed_quality_cap_shares"] = cap_shares
                        sizing["core_confirmed_quality_new_shares"] = new_shares
                if (
                    sig.get("green_decel_quality_nonconsumer_state") is True
                    and strategy in {"trend_long", "breakout_long"}
                    and sizing.get("shares_to_buy")
                    and sizing.get("net_risk_per_share")
                    and signal_risk_pct > 0
                    and GREEN_DECEL_QUALITY_NONCONSUMER_RISK_MULTIPLIER > 1.0
                ):
                    old_shares = int(sizing.get("shares_to_buy") or 0)
                    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
                    cap_pct = float(
                        sizing.get("max_position_pct_applied") or max_position_pct
                    )
                    cap_shares = int(math.floor(portfolio_value * cap_pct / entry))
                    desired_shares = max(
                        old_shares,
                        int(
                            math.floor(
                                old_shares
                                * GREEN_DECEL_QUALITY_NONCONSUMER_RISK_MULTIPLIER
                            )
                        ),
                    )
                    new_shares = min(desired_shares, cap_shares)
                    if new_shares > old_shares:
                        risk_amount = new_shares * net_risk_per_share
                        position_value = new_shares * entry
                        green_decel_quality_nonconsumer_risk_multiplier = (
                            GREEN_DECEL_QUALITY_NONCONSUMER_RISK_MULTIPLIER
                        )
                        sizing["shares_to_buy"] = new_shares
                        sizing["position_value_usd"] = round(position_value, 2)
                        sizing["position_pct_of_portfolio"] = round(
                            position_value / portfolio_value,
                            4,
                        )
                        sizing["risk_amount_usd"] = round(risk_amount, 2)
                        sizing["risk_pct"] = (
                            risk_amount / portfolio_value if portfolio_value else 0.0
                        )
                        sizing[
                            "green_decel_quality_nonconsumer_baseline_shares"
                        ] = old_shares
                        sizing[
                            "green_decel_quality_nonconsumer_desired_shares"
                        ] = desired_shares
                        sizing[
                            "green_decel_quality_nonconsumer_cap_shares"
                        ] = cap_shares
                        sizing[
                            "green_decel_quality_nonconsumer_new_shares"
                        ] = new_shares
                sizing = _apply_tsm_core_risk_multiplier(
                    sig,
                    sizing,
                    portfolio_value,
                )
                sizing = _apply_isrg_core_risk_multiplier(
                    sig,
                    sizing,
                    portfolio_value,
                )
                sizing["base_risk_pct"] = effective_risk_pct
                sizing["max_position_pct_applied"] = max(
                    max_position_pct,
                    float(sizing.get("max_position_pct_applied") or 0.0),
                )
                sizing["trade_quality_score"] = trade_quality_score
                sizing["low_tqs_haircut_exempt_sector"] = (
                    sector if sector in LOW_TQS_HAIRCUT_EXEMPT_SECTORS else None
                )
                sizing["tqs_risk_multiplier_applied"] = tqs_risk_multiplier
                sizing["trend_industrials_risk_multiplier_applied"] = (
                    trend_industrials_risk_multiplier
                )
                sizing["trend_financials_risk_multiplier_applied"] = (
                    trend_financials_risk_multiplier
                )
                sizing["financials_sector_leader_risk_multiplier_applied"] = (
                    financials_sector_leader_risk_multiplier
                )
                sizing["trend_financials_sector_leader_max_position_pct_applied"] = (
                    TREND_FINANCIALS_SECTOR_LEADER_MAX_POSITION_PCT
                    if financials_sector_leader_risk_multiplier != 1.0
                    else MAX_POSITION_PCT
                )
                sizing["risk_on_unmodified_risk_multiplier_applied"] = (
                    risk_on_unmodified_risk_multiplier
                )
                sizing["spy_relative_leader_risk_on_multiplier_applied"] = (
                    spy_relative_leader_risk_on_multiplier
                )
                sizing["trend_mid_sector_dispersion_risk_multiplier_applied"] = (
                    trend_mid_sector_dispersion_risk_multiplier
                )
                sizing["rs20_entry_state_risk_multiplier_applied"] = (
                    rs20_entry_state_risk_multiplier
                )
                sizing["core_confirmed_quality_risk_multiplier_applied"] = (
                    core_confirmed_quality_risk_multiplier
                )
                sizing["core_confirmed_quality_state"] = sig.get(
                    "core_confirmed_quality_state"
                )
                sizing["core_confirmed_quality_tqs_min"] = sig.get(
                    "core_confirmed_quality_tqs_min"
                )
                sizing["green_decel_quality_nonconsumer_risk_multiplier_applied"] = (
                    green_decel_quality_nonconsumer_risk_multiplier
                )
                sizing["green_decel_quality_nonconsumer_state"] = sig.get(
                    "green_decel_quality_nonconsumer_state"
                )
                sizing["green_decel_quality_nonconsumer_tqs_min"] = sig.get(
                    "green_decel_quality_nonconsumer_tqs_min"
                )
                sizing["signal_day_ticker_green_risk_multiplier_applied"] = (
                    signal_day_ticker_green_risk_multiplier
                )
                sizing["rs60_top_quintile_risk_multiplier_applied"] = (
                    rs60_top_quintile_risk_multiplier
                )
                sizing["price_vs_200ma_extension_risk_multiplier_applied"] = (
                    price_vs_200ma_extension_risk_multiplier
                )
                sizing[
                    "trend_price_vs_200ma_extension_risk_multiplier_applied"
                ] = trend_price_vs_200ma_extension_risk_multiplier
                sizing["clean_spy_leader_signal_day_risk_multiplier_applied"] = (
                    clean_spy_leader_signal_day_risk_multiplier
                )
                if clean_spy_leader_signal_day_cap_applied:
                    sizing["clean_spy_leader_signal_day_max_position_pct_applied"] = (
                        CLEAN_SPY_LEADER_SIGNAL_DAY_MAX_POSITION_PCT
                    )
                if clean_spy_cap_only_leader_cap_applied:
                    sizing["clean_spy_cap_only_leader_max_position_pct_applied"] = (
                        CLEAN_SPY_CAP_ONLY_LEADER_MAX_POSITION_PCT
                    )
                if clean_spy_cap_only_rs20_leader_cap_applied:
                    sizing[
                        "clean_spy_cap_only_rs20_leader_max_position_pct_applied"
                    ] = CLEAN_SPY_CAP_ONLY_RS20_LEADER_MAX_POSITION_PCT
                if breakout_commodities_cap_applied:
                    sizing["breakout_commodities_max_position_pct_applied"] = (
                        BREAKOUT_COMMODITIES_MAX_POSITION_PCT
                    )
                if trend_gold_near_high_cap_applied:
                    sizing["trend_gold_near_high_max_position_pct_applied"] = (
                        TREND_GOLD_NEAR_HIGH_MAX_POSITION_PCT
                    )
                if financials_mid_dispersion_leader_cap_applied:
                    sizing[
                        "trend_financials_mid_dispersion_leader_max_position_pct_applied"
                    ] = TREND_FINANCIALS_MID_DISPERSION_LEADER_MAX_POSITION_PCT
                sizing["ticker_minus_spy_signal_day_open_close_return_pct"] = (
                    sig.get("ticker_minus_spy_signal_day_open_close_return_pct")
                )
                sizing["signal_day_ticker_outperformed_spy"] = sig.get(
                    "signal_day_ticker_outperformed_spy"
                )
                sizing["price_vs_200ma_pct"] = sig.get("price_vs_200ma_pct")
                sizing["price_vs_200ma_extension_cutoff"] = sig.get(
                    "price_vs_200ma_extension_cutoff"
                )
                sizing["price_vs_200ma_extension_state"] = sig.get(
                    "price_vs_200ma_extension_state"
                )
                sizing["sector_ret20_dispersion"] = sig.get("sector_ret20_dispersion")
                sizing["mid_sector_dispersion"] = sig.get("mid_sector_dispersion")
                sizing["trend_tech_tight_gap_risk_multiplier_applied"] = (
                    trend_tech_tight_gap_risk_multiplier
                )
                sizing["trend_tech_gap_risk_multiplier_applied"] = (
                    trend_tech_gap_risk_multiplier
                )
                sizing["trend_tech_near_high_risk_multiplier_applied"] = (
                    trend_tech_near_high_risk_multiplier
                )
                sizing["trend_tech_dte_risk_multiplier_applied"] = (
                    trend_tech_dte_risk_multiplier
                )
                sizing["breakout_industrials_gap_risk_multiplier_applied"] = (
                    breakout_industrials_gap_risk_multiplier
                )
                sizing["breakout_comms_near_high_risk_multiplier_applied"] = (
                    breakout_comms_near_high_risk_multiplier
                )
                sizing["breakout_comms_gap_risk_multiplier_applied"] = (
                    breakout_comms_gap_risk_multiplier
                )
                sizing["breakout_financials_dte_risk_multiplier_applied"] = (
                    breakout_financials_dte_risk_multiplier
                )
                sizing["breakout_tech_dte_risk_multiplier_applied"] = (
                    breakout_tech_dte_risk_multiplier
                )
                sizing["breakout_healthcare_dte_risk_multiplier_applied"] = (
                    breakout_healthcare_dte_risk_multiplier
                )
                sizing["trend_healthcare_dte_risk_multiplier_applied"] = (
                    trend_healthcare_dte_risk_multiplier
                )
                sizing["trend_consumer_near_high_dte_risk_multiplier_applied"] = (
                    trend_consumer_near_high_dte_risk_multiplier
                )
                sizing["trend_commodities_near_high_risk_multiplier_applied"] = (
                    trend_commodities_near_high_risk_multiplier
                )
                sizing["trend_commodities_near_high_max_position_pct_applied"] = (
                    TREND_COMMODITIES_NEAR_HIGH_MAX_POSITION_PCT
                    if trend_commodities_near_high_risk_multiplier
                    == TREND_COMMODITIES_NEAR_HIGH_RISK_MULTIPLIER
                    else MAX_POSITION_PCT
                )
                sig = {**sig, "sizing": sizing}
        sized.append(sig)
    return sized
