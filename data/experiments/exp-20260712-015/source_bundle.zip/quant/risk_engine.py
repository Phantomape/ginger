"""
Risk Engine: Compute risk parameters for each trade signal.

Standard trade structure per inst_5.txt:
  entry  = breakout price (current close)
  stop   = entry − 1.5 × ATR
  target = entry + 3.5 × ATR
  R:R    ≈ 2.33:1  (3.5 ATR reward / 1.5 ATR risk)

Every trade must include:
  entry_price, stop_loss, position_size, risk_reward_ratio
"""

import logging
import math
import statistics
from collections import defaultdict

from constants import (
    ATR_STOP_MULT,
    ATR_TARGET_MULT,
    TREND_TECH_TARGET_ATR_MULT,
    TREND_COMMODITIES_TARGET_ATR_MULT,
    TREND_GOLD_TARGET_ATR_MULT,
    TREND_GOLD_TARGET_TICKERS,
    ROUND_TRIP_COST_PCT,
    EXEC_LAG_PCT,
    PRICE_VS_200MA_EXTENSION_EXCLUDED_SECTORS,
    PRICE_VS_200MA_EXTENSION_FRACTION,
    CORE_CONFIRMED_QUALITY_TQS_MIN,
    GREEN_DECEL_QUALITY_NONCONSUMER_EXCLUDED_SECTORS,
    GREEN_DECEL_QUALITY_NONCONSUMER_TQS_MIN,
    RS20_ENTRY_STATE_LEADER_MIN_REL_RETURN,
    RS60_TOP_QUINTILE_EXCLUDED_SECTORS,
    RS60_TOP_QUINTILE_FRACTION,
    TREND_MID_SECTOR_DISPERSION_MIN,
    TREND_MID_SECTOR_DISPERSION_MAX,
)

logger = logging.getLogger(__name__)

# Static sector map for the watchlist + common holdings.
# Used by LLM prompt to enforce the 40% sector concentration rule.
# Without this data the LLM cannot compute actual sector weights — the rule was blind.
# Source: GICS sector classification.  Update when adding new tickers.
SECTOR_MAP = {
    # Technology / Semiconductors
    "NVDA": "Technology", "AMD":  "Technology", "MU":   "Technology",
    "CRDO": "Technology", "INTC": "Technology", "AVGO": "Technology",
    "TSM":  "Technology", "QCOM": "Technology", "AMAT": "Technology",
    "ASML": "Technology",
    # Technology / Software & Internet
    "META": "Technology", "GOOG": "Technology", "GOOGL": "Technology",
    "MSFT": "Technology", "AAPL": "Technology", "CRM":  "Technology",
    "NOW":  "Technology", "SNOW": "Technology", "DDOG": "Technology",
    "APP":  "Technology", "PLTR": "Technology",
    # Consumer Discretionary
    "TSLA": "Consumer Discretionary", "AMZN": "Consumer Discretionary",
    "MCD":  "Consumer Discretionary", "SBUX": "Consumer Discretionary",
    "BKNG": "Consumer Discretionary", "TRIP": "Consumer Discretionary",
    # Communication Services
    "NFLX": "Communication Services", "DIS":  "Communication Services",
    "SPOT": "Communication Services",
    # Financials
    "COIN": "Financials", "V":    "Financials", "MA":   "Financials",
    "GS":   "Financials", "JPM":  "Financials",
    # Healthcare
    "LLY":  "Healthcare", "NVO":  "Healthcare",
    "UNH":  "Healthcare", "ISRG": "Healthcare",
    # Energy
    "XOM":  "Energy",     "CVX":  "Energy",
    # Industrials
    "CAT":  "Industrials", "DE":   "Industrials",
    "GE":   "Industrials", "RTX":  "Industrials",
    # ETFs (broad market)
    "QQQ":  "ETF", "SPY": "ETF", "IWM": "ETF",
    # Commodities / Safe Haven
    "IAU":  "Commodities", "GLD": "Commodities", "SLV": "Commodities",
    "GDX":  "Commodities",
}


def enrich_signal_with_risk(signal, atr, atr_target_mult=None):
    """
    Add target_price, risk_per_share, reward_per_share, risk_reward_ratio,
    and net_risk_reward_ratio to a signal dict.

    stop_price is already set by the strategy (entry − 1.5×ATR).
    This function adds the target and computes both gross and cost-adjusted R:R.

    Cost model (matches performance_engine.py):
        cost = entry_price × ROUND_TRIP_COST_PCT  (per share)
        net_reward = reward_per_share - cost
        net_risk   = risk_per_share   + cost
        net_rr     = net_reward / net_risk

    For the standard 3.5/1.5 ATR structure at entry=$100:
        gross R:R  ≈ 2.33:1
        net R:R    ≈ 1.70:1  (cost eats ~27% due to fixed-dollar cost vs variable reward)

    The gross risk_reward_ratio is kept for position-sizing gates; the net ratio
    is informational for the LLM when evaluating marginal trade quality.

    Args:
        signal (dict): Signal from signal_engine
        atr    (float): ATR value for this ticker
        atr_target_mult (float): Optional override for ATR_TARGET_MULT constant

    Returns:
        dict: Enriched signal
    """
    entry = signal["entry_price"]
    stop  = signal.get("stop_price") or round(entry - ATR_STOP_MULT * atr, 2)

    _target_mult = atr_target_mult if atr_target_mult is not None else ATR_TARGET_MULT
    target           = round(entry + _target_mult * atr, 2)
    risk_per_share   = round(entry - stop, 2)
    reward_per_share = round(target - entry, 2)
    rr_ratio         = (round(reward_per_share / risk_per_share, 2)
                        if risk_per_share > 0 else None)

    # Cost-adjusted R:R: reflects actual expected value per the performance engine's P&L model.
    # cost is fixed per share (% of entry price), so it shrinks reward AND enlarges risk equally.
    cost_per_share    = round(entry * ROUND_TRIP_COST_PCT, 4)
    net_reward        = reward_per_share - cost_per_share
    net_risk          = risk_per_share   + cost_per_share
    net_rr_ratio      = (round(net_reward / net_risk, 2)
                         if net_risk > 0 and net_reward > 0 else None)

    # Execution-lag-adjusted R:R: accounts for next-day open slippage.
    # Entry is today's close; actual fill is next-day open (typically +0.3–1.0% higher
    # on breakout days). At +0.5% gap on entry=$100: adj_entry=$100.50, stop stays $98.50.
    # adj_reward = $103.50 - $100.50 = $3.00  vs  adj_risk = $100.50 - $98.50 = $2.00 → 1.50:1
    # This field is informational — the LLM uses it to reject trades where the gap cost
    # pushes net expected value below breakeven. The gross R:R gate (≥2.0) uses close price.
    adj_entry    = round(entry * (1 + EXEC_LAG_PCT), 2)
    adj_reward   = round(target   - adj_entry, 2)
    adj_risk     = round(adj_entry - stop,     2)
    adj_net_cost = round(adj_entry * ROUND_TRIP_COST_PCT, 4)
    exec_lag_adj_rr = (
        round((adj_reward - adj_net_cost) / (adj_risk + adj_net_cost), 2)
        if adj_risk > 0 and adj_reward > adj_net_cost else None
    )

    return {
        **signal,
        "stop_price":                round(stop, 2),
        "target_price":              target,
        "risk_per_share":            risk_per_share,
        "reward_per_share":          reward_per_share,
        "risk_reward_ratio":         rr_ratio,
        "net_risk_reward_ratio":     net_rr_ratio,       # after 0.35% round-trip execution cost
        "exec_lag_adj_net_rr":       exec_lag_adj_rr,    # after +0.5% assumed next-day open gap
    }


def _retarget_signal_with_atr_mult(signal, atr, target_mult):
    """Recompute target/R:R fields for a strategy-specific target width."""
    entry = signal["entry_price"]
    stop = signal["stop_price"]
    target = round(entry + target_mult * atr, 2)
    risk_per_share = round(entry - stop, 2)
    reward_per_share = round(target - entry, 2)
    rr_ratio = (
        round(reward_per_share / risk_per_share, 2)
        if risk_per_share > 0 else None
    )

    cost_per_share = round(entry * ROUND_TRIP_COST_PCT, 4)
    net_reward = reward_per_share - cost_per_share
    net_risk = risk_per_share + cost_per_share
    net_rr_ratio = (
        round(net_reward / net_risk, 2)
        if net_risk > 0 and net_reward > 0 else None
    )

    adj_entry = round(entry * (1 + EXEC_LAG_PCT), 2)
    adj_reward = round(target - adj_entry, 2)
    adj_risk = round(adj_entry - stop, 2)
    adj_net_cost = round(adj_entry * ROUND_TRIP_COST_PCT, 4)
    exec_lag_adj_rr = (
        round((adj_reward - adj_net_cost) / (adj_risk + adj_net_cost), 2)
        if adj_risk > 0 and adj_reward > adj_net_cost else None
    )

    return {
        **signal,
        "target_price": target,
        "reward_per_share": reward_per_share,
        "risk_reward_ratio": rr_ratio,
        "net_risk_reward_ratio": net_rr_ratio,
        "exec_lag_adj_net_rr": exec_lag_adj_rr,
        "target_mult_used": target_mult,
        "target_width_applied": target_mult,
    }


def _trade_quality_score(sig, features):
    """
    Compute Trade Quality Score (TQS) — pre-calculated so LLM reads it directly.

    Formula:
        TQS = 0.40 × confidence_score
            + 0.25 × trend_score           (0-1 from feature_layer)
            + 0.20 × vol_norm              (volume_spike_ratio / 2.0, capped at 1.0)
            + 0.15 × momentum_norm         (momentum_10d_pct / 0.10, clamped to [-1, 1])

    NOTE: Weights (0.40/0.25/0.20/0.15) are heuristic — chosen by domain intuition,
    not calibrated against historical data.  Once paper-sleeve forward evidence
    accumulates 30+ closed trades per configuration, these weights should be
    calibrated by running a single-parameter sweep via the backtester.  Until
    then, treat them as reasonable defaults subject to revision.

    Returns:
        float: 0.0 – 1.0
    """
    conf       = sig.get("confidence_score", 0)
    trend_sc   = (features or {}).get("trend_score") or 0
    vol_ratio  = (features or {}).get("volume_spike_ratio") or 0
    momentum   = (features or {}).get("momentum_10d_pct") or 0

    vol_norm  = min(vol_ratio / 2.0, 1.0)
    # Negative momentum actively penalises TQS — falling stocks should not be tradeable.
    # Clamped to [-1, 1] so a -10% mover gets full -0.15 penalty (pushing TQS below 0.60).
    mom_norm  = max(-1.0, min(momentum / 0.10, 1.0))

    tqs = 0.40 * conf + 0.25 * trend_sc + 0.20 * vol_norm + 0.15 * mom_norm
    return round(max(0.0, min(tqs, 1.0)), 3)


def _sector_ret20_dispersion(features_dict):
    """Return population stdev of sector-average 20d returns, or None."""
    sector_returns = defaultdict(list)
    for ticker, features in (features_dict or {}).items():
        if not features:
            continue
        ret20 = features.get("momentum_20d_pct")
        # Exclude NaN/inf: a non-finite value (e.g. a nan momentum) survives the
        # isinstance check but makes statistics.pstdev's internal sum a bare
        # float, raising "'float' object has no attribute 'numerator'".
        if isinstance(ret20, (int, float)) and math.isfinite(ret20):
            sector_returns[SECTOR_MAP.get(ticker, "Unknown")].append(float(ret20))

    sector_avgs = [
        sum(values) / len(values)
        for values in sector_returns.values()
        if values
    ]
    if len(sector_avgs) < 2:
        return None
    return statistics.pstdev(sector_avgs)


def _rs60_top_quintile_cutoff(features_dict):
    """Return the same-day RS60 top-quintile cutoff for non-ETF stock features."""
    values = []
    for ticker, features in (features_dict or {}).items():
        if not features:
            continue
        sector = SECTOR_MAP.get(ticker, "Unknown")
        ret60 = features.get("momentum_60d_pct")
        if sector in RS60_TOP_QUINTILE_EXCLUDED_SECTORS:
            continue
        if isinstance(ret60, (int, float)):
            values.append(float(ret60))

    if not values:
        return None

    values.sort()
    index = max(
        0,
        math.ceil(len(values) * (1.0 - RS60_TOP_QUINTILE_FRACTION)) - 1,
    )
    return values[index]


def _price_vs_200ma_extension_cutoff(features_dict):
    """Return the same-day top-quartile price-vs-200MA cutoff for stocks."""
    values = []
    for ticker, features in (features_dict or {}).items():
        if not features:
            continue
        sector = SECTOR_MAP.get(ticker, "Unknown")
        price_vs_200ma = features.get("price_vs_200ma_pct")
        if sector in PRICE_VS_200MA_EXTENSION_EXCLUDED_SECTORS:
            continue
        if isinstance(price_vs_200ma, (int, float)):
            values.append(float(price_vs_200ma))

    if not values:
        return None

    values.sort()
    index = max(
        0,
        math.ceil(len(values) * (1.0 - PRICE_VS_200MA_EXTENSION_FRACTION)) - 1,
    )
    return values[index]


def enrich_signals(signals, features_dict, atr_target_mult=None):
    """
    Enrich all signals with risk parameters and Trade Quality Score.

    Args:
        signals       (list[dict]): From signal_engine.generate_signals()
        features_dict (dict):       {ticker: features} for ATR + TQS fields
        atr_target_mult (float):    Optional override for ATR_TARGET_MULT constant

    Returns:
        list[dict]: Signals with risk fields + trade_quality_score added.
        Dropped signals are stored in the module-level ``last_dropped_signals``
        list so callers (run.py, report_generator) can surface them.
    """
    enriched = []
    dropped  = []

    financials_ret20 = [
        features.get("momentum_20d_pct")
        for ticker, features in (features_dict or {}).items()
        if SECTOR_MAP.get(ticker) == "Financials"
        and features
        and isinstance(features.get("momentum_20d_pct"), (int, float))
    ]
    financials_avg_ret20 = (
        sum(financials_ret20) / len(financials_ret20)
        if financials_ret20 else None
    )
    spy_ret20 = ((features_dict or {}).get("SPY") or {}).get("momentum_20d_pct")
    sector_ret20_dispersion = _sector_ret20_dispersion(features_dict)
    mid_sector_dispersion = (
        sector_ret20_dispersion is not None
        and TREND_MID_SECTOR_DISPERSION_MIN
        < sector_ret20_dispersion
        < TREND_MID_SECTOR_DISPERSION_MAX
    )
    rs60_top_quintile_cutoff = _rs60_top_quintile_cutoff(features_dict)
    price_vs_200ma_extension_cutoff = _price_vs_200ma_extension_cutoff(features_dict)

    for sig in signals:
        ticker   = sig["ticker"]
        features = (features_dict or {}).get(ticker) or {}
        atr      = features.get("atr")

        if not atr or atr <= 0:
            logger.warning(
                f"{ticker}: ATR unavailable — signal dropped. "
                "LLM cannot size or gate without risk parameters (no stop/target/R:R)."
            )
            dropped.append({
                "ticker": ticker, "strategy": sig.get("strategy"),
                "confidence": sig.get("confidence_score"),
                "reason": "ATR unavailable",
            })
            continue  # Drop: an incomplete signal is worse than no signal

        enriched_sig = enrich_signal_with_risk(sig, atr, atr_target_mult=atr_target_mult)

        # Code-level exec_lag gate: drop signals where the overnight-gap-adjusted
        # net R:R is < 1.2.  The LLM prompt contains the same rule, but LLMs can
        # occasionally misread or skip this field.  Enforcing it here guarantees
        # no negative-EV-after-friction signal ever reaches the LLM.
        #
        # Threshold 1.2 (not 1.0) provides a margin above breakeven to account
        # for model error in the +0.5% assumed gap (actual gap can reach +1.0%
        # on strong breakout days).  At exec_lag_adj_net_rr = 1.2:
        #   adj_reward = 1.2 × (adj_risk + adj_net_cost) + adj_net_cost = EV > 0
        # Signals with standard 1.5×ATR stop on liquid watchlist stocks
        # (ATR ≥ 1.5% of price) always produce exec_lag_adj_net_rr ≥ 1.40,
        # so this gate only drops genuinely thin-stop situations.
        exec_lag_rr = enriched_sig.get("exec_lag_adj_net_rr")
        if exec_lag_rr is not None and exec_lag_rr < 1.2:
            logger.warning(
                f"{ticker}: signal dropped — exec_lag_adj_net_rr={exec_lag_rr:.2f} < 1.2 "
                "(negative EV after overnight gap + round-trip cost)"
            )
            dropped.append({
                "ticker": ticker, "strategy": sig.get("strategy"),
                "confidence": sig.get("confidence_score"),
                "exec_lag_rr": exec_lag_rr,
                "reason": f"exec_lag_adj_net_rr={exec_lag_rr:.2f} < 1.2",
            })
            continue

        # Gap vulnerability: how tight is the stop relative to typical overnight gaps?
        # Breakout stocks commonly gap 2-3% overnight.  A stop < 2% below entry
        # means a gap-through-stop can turn a planned 1% risk into 8-15% loss.
        # Surface a warning so the LLM can factor this into its decision; do NOT auto-reject.
        _entry = enriched_sig["entry_price"]
        gap_vuln = round((_entry - enriched_sig["stop_price"]) / _entry, 4) if _entry > 0 else 0
        enriched_sig["gap_vulnerability_pct"] = gap_vuln
        if gap_vuln < 0.02:
            enriched_sig["gap_warning"] = (
                f"Stop is only {gap_vuln*100:.1f}% below entry — typical overnight gaps "
                "on breakout stocks are 2-3%.  A gap through the stop would cause a loss "
                "far exceeding planned risk.  Consider widening stop or reducing size."
            )

        enriched_sig["trade_quality_score"] = _trade_quality_score(sig, features)
        # Inject sector so LLM can enforce the 40% sector concentration rule.
        # Without this field the rule was enforced blindly from LLM training knowledge.
        enriched_sig["sector"] = SECTOR_MAP.get(ticker, "Unknown")
        own_open_close_return = features.get("signal_day_ticker_open_close_return_pct")
        spy_open_close_return = ((features_dict or {}).get("SPY") or {}).get(
            "signal_day_ticker_open_close_return_pct"
        )
        enriched_sig["signal_day_ticker_open_close_return_pct"] = own_open_close_return
        enriched_sig["signal_day_ticker_green_candle"] = (
            isinstance(own_open_close_return, (int, float))
            and own_open_close_return > 0
        )
        enriched_sig["spy_signal_day_open_close_return_pct"] = spy_open_close_return
        if isinstance(own_open_close_return, (int, float)) and isinstance(
            spy_open_close_return, (int, float)
        ):
            ticker_minus_spy_open_close = own_open_close_return - spy_open_close_return
            enriched_sig["ticker_minus_spy_signal_day_open_close_return_pct"] = round(
                ticker_minus_spy_open_close,
                6,
            )
            enriched_sig["signal_day_ticker_outperformed_spy"] = (
                ticker_minus_spy_open_close > 0
            )
        else:
            enriched_sig["ticker_minus_spy_signal_day_open_close_return_pct"] = None
            enriched_sig["signal_day_ticker_outperformed_spy"] = False
        ticker_ret10 = features.get("momentum_10d_pct")
        ticker_ret60 = features.get("momentum_60d_pct")
        enriched_sig["momentum_10d_pct"] = ticker_ret10
        enriched_sig["momentum_60d_pct"] = ticker_ret60
        enriched_sig["rs60_top_quintile_cutoff"] = (
            round(rs60_top_quintile_cutoff, 6)
            if isinstance(rs60_top_quintile_cutoff, (int, float))
            else None
        )
        enriched_sig["rs60_top_quintile_state"] = (
            enriched_sig.get("strategy") in {"trend_long", "breakout_long"}
            and enriched_sig["sector"] not in RS60_TOP_QUINTILE_EXCLUDED_SECTORS
            and isinstance(ticker_ret60, (int, float))
            and isinstance(rs60_top_quintile_cutoff, (int, float))
            and ticker_ret60 >= rs60_top_quintile_cutoff
        )
        price_vs_200ma = features.get("price_vs_200ma_pct")
        enriched_sig["price_vs_200ma_pct"] = price_vs_200ma
        enriched_sig["price_vs_200ma_extension_cutoff"] = (
            round(price_vs_200ma_extension_cutoff, 6)
            if isinstance(price_vs_200ma_extension_cutoff, (int, float))
            else None
        )
        enriched_sig["price_vs_200ma_extension_state"] = (
            enriched_sig.get("strategy") in {"trend_long", "breakout_long"}
            and enriched_sig["sector"] not in PRICE_VS_200MA_EXTENSION_EXCLUDED_SECTORS
            and isinstance(price_vs_200ma, (int, float))
            and isinstance(price_vs_200ma_extension_cutoff, (int, float))
            and price_vs_200ma >= price_vs_200ma_extension_cutoff
        )
        if sector_ret20_dispersion is not None:
            enriched_sig["sector_ret20_dispersion"] = round(sector_ret20_dispersion, 4)
            enriched_sig["mid_sector_dispersion"] = mid_sector_dispersion
        ticker_ret20 = features.get("momentum_20d_pct")
        enriched_sig["momentum_20d_pct"] = ticker_ret20
        if isinstance(ticker_ret10, (int, float)) and isinstance(
            ticker_ret20, (int, float)
        ):
            enriched_sig["momentum_10d_minus_20d_pct"] = round(
                ticker_ret10 - ticker_ret20,
                6,
            )
        else:
            enriched_sig["momentum_10d_minus_20d_pct"] = None
        if isinstance(ticker_ret20, (int, float)) and isinstance(spy_ret20, (int, float)):
            rel_spy_ret20 = ticker_ret20 - spy_ret20
            enriched_sig["spy_ret20_pct"] = round(spy_ret20, 4)
            enriched_sig["ticker_ret20_minus_spy_pct"] = round(rel_spy_ret20, 4)
            enriched_sig["spy_relative_leader"] = rel_spy_ret20 > 0
            enriched_sig["rs20_entry_state_leader"] = (
                rel_spy_ret20 >= RS20_ENTRY_STATE_LEADER_MIN_REL_RETURN
            )
        tqs = enriched_sig.get("trade_quality_score")
        enriched_sig["core_confirmed_quality_tqs_min"] = (
            CORE_CONFIRMED_QUALITY_TQS_MIN
        )
        enriched_sig["core_confirmed_quality_state"] = (
            enriched_sig.get("strategy") in {"trend_long", "breakout_long"}
            and isinstance(tqs, (int, float))
            and float(tqs) >= CORE_CONFIRMED_QUALITY_TQS_MIN
            and enriched_sig.get("rs20_entry_state_leader") is True
            and enriched_sig.get("signal_day_ticker_green_candle") is True
        )
        enriched_sig["green_decel_quality_nonconsumer_tqs_min"] = (
            GREEN_DECEL_QUALITY_NONCONSUMER_TQS_MIN
        )
        enriched_sig["green_decel_quality_nonconsumer_excluded_sector"] = (
            enriched_sig["sector"] in GREEN_DECEL_QUALITY_NONCONSUMER_EXCLUDED_SECTORS
        )
        enriched_sig["green_decel_quality_nonconsumer_state"] = (
            enriched_sig.get("strategy") in {"trend_long", "breakout_long"}
            and enriched_sig.get("signal_day_ticker_green_candle") is True
            and isinstance(tqs, (int, float))
            and float(tqs) >= GREEN_DECEL_QUALITY_NONCONSUMER_TQS_MIN
            and enriched_sig["sector"]
            not in GREEN_DECEL_QUALITY_NONCONSUMER_EXCLUDED_SECTORS
            and isinstance(ticker_ret10, (int, float))
            and isinstance(ticker_ret20, (int, float))
            and ticker_ret10 > 0
            and ticker_ret20 > 0
            and ticker_ret10 < ticker_ret20
        )
        if enriched_sig["sector"] == "Financials":
            if (
                isinstance(ticker_ret20, (int, float))
                and isinstance(financials_avg_ret20, (int, float))
            ):
                rel_ret20 = ticker_ret20 - financials_avg_ret20
                enriched_sig["sector_avg_ret20_pct"] = round(financials_avg_ret20, 4)
                enriched_sig["ticker_ret20_minus_sector_avg_pct"] = round(rel_ret20, 4)
                enriched_sig["financials_sector_leader"] = rel_ret20 > 0
        if (
            enriched_sig.get("strategy") == "trend_long"
            and enriched_sig["sector"] == "Technology"
        ):
            # exp-20260425-027: Technology trend alpha was being clipped by the
            # shared target width. Keep the override narrow to avoid replaying
            # the rejected broad trend-widening family.
            enriched_sig = _retarget_signal_with_atr_mult(
                enriched_sig,
                atr,
                TREND_TECH_TARGET_ATR_MULT,
            )
            enriched_sig["tech_trend_target_width_applied"] = (
                TREND_TECH_TARGET_ATR_MULT
            )
        if (
            enriched_sig.get("strategy") == "trend_long"
            and enriched_sig["sector"] == "Commodities"
        ):
            # exp-20260425-031: commodity trend exposure carried useful
            # convexity; the alpha leak was clipping winners, not oversizing.
            # exp-20260430-032 keeps the extra extension only for gold ETFs;
            # SLV kept the 7 ATR target because prior wider commodity tests
            # were hurt by the silver path.
            commodity_target_mult = (
                TREND_GOLD_TARGET_ATR_MULT
                if ticker in TREND_GOLD_TARGET_TICKERS
                else TREND_COMMODITIES_TARGET_ATR_MULT
            )
            enriched_sig = _retarget_signal_with_atr_mult(
                enriched_sig,
                atr,
                commodity_target_mult,
            )
            enriched_sig["commodity_trend_target_width_applied"] = (
                commodity_target_mult
            )
            if ticker in TREND_GOLD_TARGET_TICKERS:
                enriched_sig["gold_trend_target_width_applied"] = (
                    TREND_GOLD_TARGET_ATR_MULT
                )
        # Inject days_to_earnings for ALL signal types (not just earnings_event_long).
        # The LLM prompt blocks ANY new trade when dte ≤ 4 — including trend_long and
        # breakout_long — but the LLM has no way to enforce this rule without the data.
        # A valid 20-day breakout 3 days before earnings exposes the position to an
        # ±8-15% overnight gap that overwhelms the 1.5×ATR stop.
        dte = features.get("days_to_earnings")
        if dte is not None:
            enriched_sig["days_to_earnings"] = dte
        for key in (
            "last_earnings_date",
            "days_since_last_earnings",
            "post_earnings_continuation_confirmed",
            "post_earnings_event_date",
        ):
            if key in features and features.get(key) is not None:
                enriched_sig[key] = features.get(key)
        enriched.append(enriched_sig)

    # Store for inspection by callers (report_generator, run.py logging).
    # Mutate in-place so that callers holding a reference to the list see updates.
    last_dropped_signals.clear()
    last_dropped_signals.extend(dropped)
    if dropped:
        logger.info(
            f"Enrichment dropped {len(dropped)} signal(s): "
            + ", ".join(f"{d['ticker']}({d['reason']})" for d in dropped)
        )

    return enriched


# Module-level storage for signals dropped during the last enrich_signals() call.
# Callers can read this after enrich_signals() returns to surface dropped signals
# in reports, logs, or LLM prompts.  Reset on each enrich_signals() invocation.
last_dropped_signals: list[dict] = []
