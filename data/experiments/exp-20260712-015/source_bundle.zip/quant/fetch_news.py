#!/usr/bin/env python3
"""
Main entry point for news collection.

Usage:
    python fetch_news.py
"""

import json
import logging
from datetime import datetime

from data_paths import daily_artifact_path
from sources import get_all_sources
from parser import parse_feed_with_diagnostics, deduplicate_items, sort_items_by_date


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def fetch_all_news():
    """
    Fetch news from all sources and return normalized items.

    Returns:
        tuple[list, list]: All news items and per-source diagnostics
    """
    all_items = []
    source_stats = []
    sources = get_all_sources()

    logger.info(f"Starting news collection from {len(sources)} sources")

    for source in sources:
        url = source["url"]
        source_type = source["source_type"]
        metadata = source.get("metadata", {})

        try:
            items, diagnostics = parse_feed_with_diagnostics(url, source_type, metadata)
            all_items.extend(items)
            source_stats.append(diagnostics)
        except Exception as e:
            logger.error(f"Failed to process source {url}: {e}")
            source_stats.append({
                "url": url,
                "source_type": source_type,
                "metadata": dict(metadata or {}),
                "request_headers_used": {},
                "status": None,
                "bozo": False,
                "bozo_exception": None,
                "entry_count": 0,
                "parsed_item_count": 0,
                "error": str(e),
            })
            # Continue with other sources
            continue

    logger.info(f"Collected {len(all_items)} total items before deduplication")
    return all_items, source_stats


def save_to_file(items, output_dir="data"):
    """
    Save news items to a daily JSON file.

    Args:
        items (list): List of news items to save
        output_dir (str): Directory to save the file in

    Returns:
        str: Path to the saved file
    """
    # Generate filename with today's date
    today = datetime.now().strftime("%Y%m%d")
    filepath = daily_artifact_path("news", today, output_dir)
    filepath.parent.mkdir(parents=True, exist_ok=True)

    # Save to JSON file
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(items, f, indent=2, ensure_ascii=False)

    logger.info(f"Saved {len(items)} items to {filepath}")
    return str(filepath)


def save_source_stats(source_stats, output_dir="data"):
    today = datetime.now().strftime("%Y%m%d")
    filepath = daily_artifact_path("news_source_stats", today, output_dir)
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(source_stats, f, indent=2, ensure_ascii=False)
    logger.info(f"Saved {len(source_stats)} source stats to {filepath}")
    return str(filepath)


def main():
    """
    Main function to orchestrate news collection.
    """
    logger.info("=" * 50)
    logger.info("Starting News Collection")
    logger.info("=" * 50)

    try:
        # Step 1: Fetch all news
        all_items, source_stats = fetch_all_news()

        if not all_items:
            logger.warning("No news items collected")
            return

        # Step 2: Deduplicate
        unique_items = deduplicate_items(all_items)

        # Step 3: Sort by date (newest first)
        sorted_items = sort_items_by_date(unique_items)

        # Step 4: Save to file
        filepath = save_to_file(sorted_items)
        save_source_stats(source_stats)

        logger.info("=" * 50)
        logger.info(f"News collection complete!")
        logger.info(f"Total items: {len(sorted_items)}")
        logger.info(f"Output file: {filepath}")
        logger.info("=" * 50)

    except Exception as e:
        logger.error(f"Fatal error in main: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
