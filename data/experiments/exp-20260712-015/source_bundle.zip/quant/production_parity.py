"""Production helpers that mirror backtester entry-side mechanics.

These functions keep run.py from advertising trades that the backtester would
not execute, and expose follow-through add-ons as explicit actions instead of
accidental duplicate new entries.
"""

import math

import pandas as pd

from constants import (
    ADVERSE_GAP_CANCEL_PCT,
    ADDON_CHECKPOINT_DAYS,
    ADDON_ENABLED,
    ADDON_FRACTION_OF_ORIGINAL_SHARES,
    ADDON_MAX_POSITION_PCT,
    ADDON_MIN_RS_VS_SPY,
    ADDON_MIN_UNREALIZED_PCT,
    ADDON_SPY_RELATIVE_LEADER_MAX_POSITION_PCT,
    AMPLE_SLOT_STOCK_RANK1_AVAILABLE_SLOTS_MIN,
    AMPLE_SLOT_STOCK_RANK1_EXCLUDED_SECTORS,
    AMPLE_SLOT_STOCK_RANK1_RISK_MULTIPLIER,
    DEFER_BREAKOUT_MAX_MIN_INDEX_PCT_FROM_MA,
    DEFER_BREAKOUT_WHEN_SLOTS_LTE,
    MAX_POSITION_PCT,
    MAX_PER_SECTOR,
    MAX_PORTFOLIO_HEAT,
    MAX_POSITIONS,
    SCARCE_SLOT_RANK1_RISK_MULTIPLIER,
    SECOND_ADDON_CHECKPOINT_DAYS,
    SECOND_ADDON_ENABLED,
    SECOND_ADDON_FRACTION_OF_ORIGINAL_SHARES,
    SECOND_ADDON_MAX_POSITION_PCT,
    SECOND_ADDON_MIN_RS_VS_SPY,
    SECOND_ADDON_MIN_UNREALIZED_PCT,
    TRAILING_STOP_PCT,
)
from open_position_schema import (
    CORE_SLEEVES,
    CORE_SLOT_POLICIES,
    CORE_STRATEGY_POSITION_TAGS,
    NON_CORE_SLEEVES,
    NON_CORE_SLOT_POLICIES,
    account_positions,
    infer_position_sleeve,
    position_consumes_core_slot as schema_position_consumes_core_slot,
)
from position_intent import resolve_intended_shares

try:
    from price_asof_guard import date10, normalise_price_dates
except ImportError:  # pragma: no cover - package-style imports in tests
    from quant.price_asof_guard import date10, normalise_price_dates

TRAILING_PARTIAL_REDUCE_ENABLED = False
def position_was_spy_relative_leader(pos, ticker_df=None, spy_df=None, entry_idx=None, spy_entry_idx=None):
    """Return whether the position qualified as a 20-day ticker-vs-SPY leader at entry."""
    multipliers = pos.get("sizing_multipliers") or {}
    if not multipliers and isinstance(pos.get("sizing"), dict):
        multipliers = pos["sizing"].get("sizing_multipliers") or {}
    if multipliers.get("spy_relative_leader_risk_on_multiplier_applied", 1.0) > 1.0:
        return True
    if pos.get("spy_relative_leader") is True:
        return True
    if ticker_df is None or spy_df is None or entry_idx is None or spy_entry_idx is None:
        return False
    if entry_idx < 20 or spy_entry_idx < 20:
        return False
    try:
        ticker_entry = float(ticker_df["Close"].iloc[entry_idx])
        ticker_base = float(ticker_df["Close"].iloc[entry_idx - 20])
        spy_entry = float(spy_df["Close"].iloc[spy_entry_idx])
        spy_base = float(spy_df["Close"].iloc[spy_entry_idx - 20])
    except (KeyError, TypeError, ValueError, IndexError):
        return False
    if ticker_base <= 0 or spy_base <= 0:
        return False
    return ((ticker_entry - ticker_base) / ticker_base) > ((spy_entry - spy_base) / spy_base)


def _positive_positions(open_positions):
    return account_positions(open_positions, positive_only=True)


def _position_strategy_tag(position):
    for key in (
        "opened_by_strategy",
        "strategy",
        "entry_strategy",
        "source_strategy",
    ):
        value = position.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return None


def _normalised_text(value):
    return str(value or "").strip().lower()


def _position_sleeve(position):
    return infer_position_sleeve(position, position.get("position_group"))


def position_consumes_core_slot(position):
    """Return whether a live position should consume core strategy capacity."""
    return schema_position_consumes_core_slot(position, position.get("position_group"))


def is_core_strategy_position(position):
    """Return whether a live ledger position should consume core strategy slots."""
    return position_consumes_core_slot(position)


def count_core_strategy_positions(open_positions):
    """Count live positions opened by the core strategies replayed by backtests."""
    return sum(
        1
        for position in _positive_positions(open_positions)
        if is_core_strategy_position(position)
    )


def build_slot_accounting_summary(open_positions, max_positions=MAX_POSITIONS):
    """Expose live-vs-strategy slot accounting for operator review."""
    positions = _positive_positions(open_positions)
    core_positions = []
    ignored_positions = []
    for position in positions:
        consumes_core_slot = position_consumes_core_slot(position)
        row = {
            "ticker": position.get("ticker"),
            "opened_by_strategy": _position_strategy_tag(position),
            "sleeve": _position_sleeve(position),
            "slot_policy": position.get("slot_policy"),
            "consumes_core_slot": consumes_core_slot,
            "shares": position.get("shares"),
        }
        if consumes_core_slot:
            core_positions.append(row)
        else:
            ignored_positions.append(row)

    live_active = len(positions)
    strategy_active = len(core_positions)
    return {
        "capacity_policy": "core_strategy_slots_only",
        "accounting_note": (
            "All real positions count toward account heat/cash/risk, but only "
            "positions with core sleeve/strategy policy consume core entry slots."
        ),
        "max_positions": max_positions,
        "live_active_positions": live_active,
        "live_available_slots": max(0, max_positions - live_active),
        "total_account_active_positions": live_active,
        "total_account_available_slots_shadow": max(0, max_positions - live_active),
        "strategy_active_positions": strategy_active,
        "strategy_available_slots": max(0, max_positions - strategy_active),
        "core_slot_active_positions": strategy_active,
        "core_slot_available_slots": max(0, max_positions - strategy_active),
        "core_strategy_position_tags": sorted(CORE_STRATEGY_POSITION_TAGS),
        "core_sleeves": sorted(CORE_SLEEVES),
        "non_core_sleeves": sorted(NON_CORE_SLEEVES),
        "core_strategy_positions": core_positions,
        "non_strategy_positions_ignored_for_strategy_slots": ignored_positions,
    }


def _signal_key(signal):
    return (
        str((signal or {}).get("ticker") or "").upper(),
        str((signal or {}).get("strategy") or ""),
    )


def _decision_for_signal(signal, selected_signals, entry_execution_plan, *, heat_blocked=False):
    key = _signal_key(signal)
    plan = entry_execution_plan or {}
    base = {
        "active_positions": plan.get("active_positions"),
        "max_positions": plan.get("max_positions"),
        "available_slots": plan.get("available_slots"),
    }
    if heat_blocked:
        return {
            **base,
            "decision": "deferred",
            "reason": "portfolio_heat_blocked",
        }

    selected = {_signal_key(row) for row in selected_signals or []}
    deferred_breakouts = {
        _signal_key(row) for row in plan.get("deferred_breakout_signals") or []
    }
    slot_sliced = {_signal_key(row) for row in plan.get("slot_sliced_signals") or []}

    if key in selected:
        return {**base, "decision": "buy", "reason": "selected_by_entry_plan"}
    if key in deferred_breakouts:
        return {**base, "decision": "deferred", "reason": "scarce_slot_breakout_deferred"}
    if key in slot_sliced:
        return {**base, "decision": "deferred", "reason": "slot_sliced"}
    return {**base, "decision": "deferred", "reason": "not_selected_by_entry_plan"}


def _compact_signal_for_review(signal, rank):
    sizing = signal.get("sizing") or {}
    return {
        "rank": rank,
        "ticker": signal.get("ticker"),
        "strategy": signal.get("strategy"),
        "sector": signal.get("sector", "Unknown"),
        "entry_price": signal.get("entry_price"),
        "stop_price": signal.get("stop_price"),
        "target_price": signal.get("target_price"),
        "risk_reward_ratio": signal.get("risk_reward_ratio"),
        "trade_quality_score": signal.get("trade_quality_score"),
        "confidence_score": signal.get("confidence_score"),
        "days_to_earnings": signal.get("days_to_earnings"),
        "shares_to_buy": sizing.get("shares_to_buy"),
        "position_value_usd": sizing.get("position_value_usd"),
    }


def build_entry_candidate_review(
    candidate_signals,
    *,
    live_selected_signals,
    live_entry_execution_plan,
    strategy_selected_signals,
    strategy_entry_execution_plan,
    total_account_selected_signals=None,
    total_account_entry_execution_plan=None,
    open_positions=None,
    live_heat_blocked=False,
    max_positions=MAX_POSITIONS,
):
    """Build a read-only surface showing live and backtest-style slot decisions."""
    candidates = []
    for rank, signal in enumerate(candidate_signals or [], 1):
        live_decision = _decision_for_signal(
            signal,
            live_selected_signals,
            live_entry_execution_plan,
            heat_blocked=live_heat_blocked,
        )
        strategy_decision = _decision_for_signal(
            signal,
            strategy_selected_signals,
            strategy_entry_execution_plan,
        )
        total_account_decision = None
        if total_account_entry_execution_plan is not None:
            total_account_decision = _decision_for_signal(
                signal,
                total_account_selected_signals,
                total_account_entry_execution_plan,
            )
        row = {
            **_compact_signal_for_review(signal, rank),
            "live_accounting": live_decision,
            "backtest_accounting": strategy_decision,
        }
        if total_account_decision is not None:
            row["total_accounting_shadow"] = total_account_decision
        if (
            live_decision.get("decision") != "buy"
            and strategy_decision.get("decision") == "buy"
        ):
            row["operator_review_reason"] = (
                "backtest_accounting_buy_but_live_accounting_deferred"
            )
        elif (
            total_account_decision is not None
            and live_decision.get("decision") == "buy"
            and total_account_decision.get("decision") != "buy"
        ):
            row["operator_review_reason"] = (
                "total_account_would_defer_but_core_capacity_allows"
            )
        candidates.append(row)

    return {
        "diagnostic_only": True,
        "orders_changed": False,
        "description": (
            "Read-only operator surface: production live accounting uses core "
            "strategy slot capacity; total account positions still count toward "
            "heat/cash/risk and are shown as a shadow capacity check."
        ),
        "slot_accounting": build_slot_accounting_summary(
            open_positions,
            max_positions=max_positions,
        ),
        "candidate_count": len(candidates),
        "live_buy_count": sum(
            1 for row in candidates if row["live_accounting"]["decision"] == "buy"
        ),
        "backtest_accounting_buy_count": sum(
            1 for row in candidates if row["backtest_accounting"]["decision"] == "buy"
        ),
        "total_accounting_buy_count": sum(
            1
            for row in candidates
            if (row.get("total_accounting_shadow") or {}).get("decision") == "buy"
        ),
        "operator_review_count": sum(
            1 for row in candidates if row.get("operator_review_reason")
        ),
        "candidates": candidates,
    }


def filter_entry_signal_candidates(
    signals,
    open_positions=None,
    active_tickers=None,
    market_regime=None,
    spy_pct_from_ma=None,
    qqq_pct_from_ma=None,
    max_per_sector=MAX_PER_SECTOR,
):
    """Apply shared pre-sizing entry candidate gates used by production/backtest."""
    planned = list(signals or [])
    audit = {
        "signals_before_entry_filters": len(planned),
        "already_held_dropped": [],
        "sector_cap_dropped": [],
        "bear_shallow_dropped": [],
        "signals_after_entry_filters": None,
        "max_per_sector": max_per_sector,
        "bear_shallow_active": False,
    }

    held = set(active_tickers or [])
    held.update(p.get("ticker") for p in _positive_positions(open_positions))
    held.discard(None)
    if held:
        kept = []
        for sig in planned:
            if sig.get("ticker") in held:
                audit["already_held_dropped"].append(sig)
            else:
                kept.append(sig)
        planned = kept

    sector_counts = {}
    kept = []
    for sig in planned:
        sector = sig.get("sector", "Unknown")
        sector_counts[sector] = sector_counts.get(sector, 0) + 1
        if sector_counts[sector] <= max_per_sector:
            kept.append(sig)
        else:
            audit["sector_cap_dropped"].append(sig)
    planned = kept

    regime = str(market_regime or "").upper()
    bear_shallow = (
        regime == "BEAR"
        and spy_pct_from_ma is not None
        and qqq_pct_from_ma is not None
        and min(spy_pct_from_ma, qqq_pct_from_ma) > -0.05
    )
    audit["bear_shallow_active"] = bear_shallow
    if bear_shallow:
        bear_sectors = {"Commodities", "Healthcare"}
        kept = []
        for sig in planned:
            if (
                sig.get("sector") in bear_sectors
                and (sig.get("trade_quality_score") or 0) >= 0.75
            ):
                kept.append(sig)
            else:
                audit["bear_shallow_dropped"].append(sig)
        planned = kept

    audit["signals_after_entry_filters"] = len(planned)
    return planned, audit


def risk_pct_for_market_state(
    market_regime,
    spy_pct_from_ma=None,
    qqq_pct_from_ma=None,
):
    """Return shared regime-adjusted risk_pct override, or None for default."""
    regime = str(market_regime or "").upper()
    if regime == "NEUTRAL":
        return 0.0075
    if (
        regime == "BEAR"
        and spy_pct_from_ma is not None
        and qqq_pct_from_ma is not None
        and min(spy_pct_from_ma, qqq_pct_from_ma) > -0.05
    ):
        return 0.005
    return None


def _apply_scarce_slot_rank1_topup(
    signals,
    available_slots,
    multiplier=None,
):
    if multiplier is None:
        multiplier = SCARCE_SLOT_RANK1_RISK_MULTIPLIER
    if available_slots != 1 or not signals or multiplier <= 1.0:
        return signals, []

    planned = list(signals)
    sig = dict(planned[0])
    sizing = dict(sig.get("sizing") or {})
    old_shares = int(sizing.get("shares_to_buy") or 0)
    if old_shares <= 0:
        return signals, []

    entry = float(sizing.get("entry_price") or sig.get("entry_price") or 0.0)
    portfolio_value = float(sizing.get("portfolio_value_usd") or 0.0)
    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
    if entry <= 0 or portfolio_value <= 0 or net_risk_per_share <= 0:
        return signals, []

    cap_pct = float(sizing.get("max_position_pct_applied") or MAX_POSITION_PCT)
    desired_shares = max(old_shares, int(math.floor(old_shares * multiplier)))
    cap_shares = int(math.floor(portfolio_value * cap_pct / entry))
    new_shares = min(desired_shares, cap_shares)
    if new_shares <= old_shares:
        return signals, []

    risk_amount = new_shares * net_risk_per_share
    position_value = new_shares * entry
    sizing["shares_to_buy"] = new_shares
    sizing["position_value_usd"] = round(position_value, 2)
    sizing["position_pct_of_portfolio"] = round(position_value / portfolio_value, 4)
    sizing["risk_amount_usd"] = round(risk_amount, 2)
    sizing["risk_pct"] = risk_amount / portfolio_value
    sizing["scarce_slot_rank1_state"] = True
    sizing["scarce_slot_rank1_available_slots"] = available_slots
    sizing["scarce_slot_rank1_baseline_shares"] = old_shares
    sizing["scarce_slot_rank1_desired_shares"] = desired_shares
    sizing["scarce_slot_rank1_cap_shares"] = cap_shares
    sizing["scarce_slot_rank1_new_shares"] = new_shares
    sizing["scarce_slot_rank1_risk_multiplier_applied"] = multiplier
    sig["sizing"] = sizing
    planned[0] = sig
    return planned, [
        {
            "ticker": sig.get("ticker"),
            "strategy": sig.get("strategy"),
            "sector": sig.get("sector", "Unknown"),
            "available_slots": available_slots,
            "baseline_shares": old_shares,
            "desired_shares": desired_shares,
            "cap_shares": cap_shares,
            "new_shares": new_shares,
            "multiplier": multiplier,
        }
    ]


def _apply_ample_slot_stock_rank1_topup(
    signals,
    available_slots,
    multiplier=None,
):
    if multiplier is None:
        multiplier = AMPLE_SLOT_STOCK_RANK1_RISK_MULTIPLIER
    if (
        available_slots < AMPLE_SLOT_STOCK_RANK1_AVAILABLE_SLOTS_MIN
        or not signals
        or multiplier <= 1.0
    ):
        return signals, []

    planned = list(signals)
    sig = dict(planned[0])
    sector = sig.get("sector")
    if not sector or sector in AMPLE_SLOT_STOCK_RANK1_EXCLUDED_SECTORS:
        return signals, []

    sizing = dict(sig.get("sizing") or {})
    old_shares = int(sizing.get("shares_to_buy") or 0)
    if old_shares <= 0:
        return signals, []

    entry = float(sizing.get("entry_price") or sig.get("entry_price") or 0.0)
    portfolio_value = float(sizing.get("portfolio_value_usd") or 0.0)
    net_risk_per_share = float(sizing.get("net_risk_per_share") or 0.0)
    if entry <= 0 or portfolio_value <= 0 or net_risk_per_share <= 0:
        return signals, []

    cap_pct = float(sizing.get("max_position_pct_applied") or MAX_POSITION_PCT)
    desired_shares = max(old_shares, int(math.floor(old_shares * multiplier)))
    cap_shares = int(math.floor(portfolio_value * cap_pct / entry))
    new_shares = min(desired_shares, cap_shares)
    if new_shares <= old_shares:
        return signals, []

    risk_amount = new_shares * net_risk_per_share
    position_value = new_shares * entry
    sizing["shares_to_buy"] = new_shares
    sizing["position_value_usd"] = round(position_value, 2)
    sizing["position_pct_of_portfolio"] = round(position_value / portfolio_value, 4)
    sizing["risk_amount_usd"] = round(risk_amount, 2)
    sizing["risk_pct"] = risk_amount / portfolio_value
    sizing["ample_slot_stock_rank1_state"] = True
    sizing["ample_slot_stock_rank1_available_slots"] = available_slots
    sizing["ample_slot_stock_rank1_baseline_shares"] = old_shares
    sizing["ample_slot_stock_rank1_desired_shares"] = desired_shares
    sizing["ample_slot_stock_rank1_cap_shares"] = cap_shares
    sizing["ample_slot_stock_rank1_new_shares"] = new_shares
    sizing["ample_slot_stock_rank1_risk_multiplier_applied"] = multiplier
    sig["sizing"] = sizing
    planned[0] = sig
    return planned, [
        {
            "ticker": sig.get("ticker"),
            "strategy": sig.get("strategy"),
            "sector": sector,
            "available_slots": available_slots,
            "baseline_shares": old_shares,
            "desired_shares": desired_shares,
            "cap_shares": cap_shares,
            "new_shares": new_shares,
            "multiplier": multiplier,
        }
    ]


def plan_entry_candidates(
    signals,
    open_positions,
    market_context=None,
    max_positions=MAX_POSITIONS,
    defer_breakout_when_slots_lte=DEFER_BREAKOUT_WHEN_SLOTS_LTE,
    defer_breakout_max_min_index_pct_from_ma=DEFER_BREAKOUT_MAX_MIN_INDEX_PCT_FROM_MA,
    active_positions_count=None,
    active_positions_scope=None,
):
    """Apply the backtester's scarce-slot breakout deferral and slot slicing."""
    market_context = market_context or {}
    input_signals = list(signals or [])
    active_positions = (
        int(active_positions_count)
        if active_positions_count is not None
        else len(_positive_positions(open_positions))
    )
    active_positions_scope = active_positions_scope or (
        "provided_active_positions_count"
        if active_positions_count is not None
        else "all_positive_account_positions"
    )
    slots = max(0, max_positions - active_positions)

    planned = list(input_signals)
    deferred_breakouts = []
    min_index_pct_from_ma = None
    state_ok = True
    if defer_breakout_max_min_index_pct_from_ma is not None:
        spy_pct = market_context.get("spy_pct_from_ma")
        qqq_pct = market_context.get("qqq_pct_from_ma")
        if spy_pct is not None and qqq_pct is not None:
            min_index_pct_from_ma = min(spy_pct, qqq_pct)
            state_ok = min_index_pct_from_ma <= defer_breakout_max_min_index_pct_from_ma
        else:
            state_ok = False

    if (
        defer_breakout_when_slots_lte is not None
        and slots <= defer_breakout_when_slots_lte
        and state_ok
    ):
        kept = []
        for sig in planned:
            if sig.get("strategy") == "breakout_long":
                deferred_breakouts.append({
                    "ticker": sig.get("ticker"),
                    "strategy": sig.get("strategy"),
                    "sector": sig.get("sector", "Unknown"),
                    "available_slots": slots,
                    "trade_quality_score": sig.get("trade_quality_score"),
                    "confidence_score": sig.get("confidence_score"),
                    "pct_from_52w_high": sig.get("pct_from_52w_high"),
                    "entry_price": sig.get("entry_price"),
                    "stop_price": sig.get("stop_price"),
                    "target_price": sig.get("target_price"),
                    "min_index_pct_from_ma": min_index_pct_from_ma,
                })
            else:
                kept.append(sig)
        planned = kept

    signals_after_deferral = len(planned)
    slot_sliced = planned[slots:] if slots >= 0 else planned
    planned = planned[:slots]
    planned, scarce_slot_rank1_topups = _apply_scarce_slot_rank1_topup(
        planned,
        slots,
    )
    planned, ample_slot_stock_rank1_topups = _apply_ample_slot_stock_rank1_topup(
        planned,
        slots,
    )

    return planned, {
        "active_positions": active_positions,
        "active_positions_scope": active_positions_scope,
        "max_positions": max_positions,
        "available_slots": slots,
        "signals_before_entry_plan": len(input_signals),
        "signals_after_deferral": signals_after_deferral,
        "signals_after_entry_plan": len(planned),
        "deferred_breakout_signals": deferred_breakouts,
        "slot_sliced_signals": slot_sliced,
        "scarce_slot_rank1_topups": scarce_slot_rank1_topups,
        "ample_slot_stock_rank1_topups": ample_slot_stock_rank1_topups,
        "defer_breakout_when_slots_lte": defer_breakout_when_slots_lte,
        "defer_breakout_max_min_index_pct_from_ma": (
            defer_breakout_max_min_index_pct_from_ma
        ),
        "min_index_pct_from_ma": min_index_pct_from_ma,
    }


def classify_entry_open_cancel(
    fill_price,
    signal_entry,
    stop_price=None,
    upside_gap_cancel_pct=None,
    adverse_gap_cancel_pct=ADVERSE_GAP_CANCEL_PCT,
):
    """Return the shared next-open cancel reason, or None when entry may fill."""
    if fill_price is None or signal_entry is None:
        return None
    fill = float(fill_price)
    entry = float(signal_entry)
    if upside_gap_cancel_pct is not None and fill > entry * (1.0 + upside_gap_cancel_pct):
        return "gap_cancel"
    if adverse_gap_cancel_pct is not None and fill < entry * (1.0 - adverse_gap_cancel_pct):
        return "adverse_gap_down_cancel"
    if stop_price is not None and fill <= float(stop_price):
        return "stop_breach_cancel"
    return None


def production_trailing_stop_price(high_water, trailing_stop_pct=TRAILING_STOP_PCT):
    """Return the production trailing-stop trigger price from high-water mark."""
    if high_water is None or high_water <= 0:
        return None
    return round(float(high_water) * (1.0 - trailing_stop_pct), 2)


def suggested_reduce_pct_for_rules(
    triggered_rules,
    unrealized_pnl_pct,
    trailing_partial_reduce_enabled=TRAILING_PARTIAL_REDUCE_ENABLED,
):
    """Return the shared production reduce percentage for executable reduce rules.

    Full-position target and ATR stop exits are represented by TARGET_EXIT /
    ATR_EXIT in preflight, not by partial REDUCE percentages. Profit-lock
    ladders are diagnostic only until a shared backtest/production policy
    proves they add value.
    """
    rule_names = {r.get("rule", "") for r in triggered_rules or []}

    if "HARD_STOP" in rule_names:
        return 100
    if "ATR_STOP" in rule_names:
        return 0
    if "TRAILING_STOP" in rule_names and trailing_partial_reduce_enabled:
        return 25 if (unrealized_pnl_pct or 0) > 0.30 else 50
    if "TRAILING_STOP" in rule_names and len(rule_names) == 1:
        return 0
    if "APPROACHING_HARD_STOP" in rule_names:
        return 0
    if "SIGNAL_TARGET" in rule_names:
        return 100
    if "PROFIT_TARGET" in rule_names:
        return 0
    if "PROFIT_LADDER_30" in rule_names:
        return 0
    if "PROFIT_LADDER_50" in rule_names:
        return 0
    if "TIME_STOP" in rule_names:
        return 0
    return 0


def partial_reduce_shares(current_shares, reduce_pct):
    """Return whole shares to reduce using the production floor semantics."""
    if current_shares is None or reduce_pct is None:
        return 0
    return max(0, math.floor(int(current_shares) * float(reduce_pct) / 100.0))


def _price_at(df, idx, field):
    if df is None or idx is None or field not in df:
        return None
    try:
        value = df[field].iloc[idx]
        return float(value.item() if hasattr(value, "item") else value)
    except (TypeError, ValueError, IndexError, KeyError):
        return None


def _latest_close(df):
    if df is None or len(df) == 0 or "Close" not in df:
        return None
    value = df["Close"].iloc[-1]
    return float(value.item() if hasattr(value, "item") else value)


def _latest_ohlcv_date(df):
    if df is None or len(df) == 0:
        return None
    try:
        if "Date" in df:
            return date10(df["Date"].iloc[-1])
        return date10(df.index[-1])
    except Exception:
        return None


def _positive_price(value):
    try:
        parsed = float(value.item() if hasattr(value, "item") else value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(parsed) or parsed <= 0:
        return None
    return parsed


def _current_or_latest_close(
    *,
    df,
    ticker,
    current_prices,
    current_price_dates,
    required_date,
):
    ticker = str(ticker or "").upper()
    mapped_date = None
    if current_price_dates is not None:
        mapped_date = current_price_dates.get(ticker)
    if current_price_dates is None or mapped_date == required_date:
        mapped = _positive_price((current_prices or {}).get(ticker))
        if mapped is not None:
            return mapped
    return _latest_close(df)


def _entry_index(df, entry_date):
    entry_ts = pd.Timestamp(entry_date)
    matching = df.index[df.index >= entry_ts]
    if len(matching) == 0:
        return None
    return df.index.get_loc(matching[0])


def _position_heat_stop(portfolio_heat, ticker):
    for item in (portfolio_heat or {}).get("position_breakdown", []) or []:
        if item.get("ticker") == ticker:
            return item.get("effective_stop")
    return None


def cap_followthrough_addon_shares(
    ticker,
    requested_shares,
    current_shares,
    price,
    portfolio_value,
    addon_position_cap,
    portfolio_heat=None,
):
    if requested_shares <= 0 or price <= 0 or not portfolio_value:
        return 0, {"requested_shares": requested_shares, "cap_reason": "invalid_input"}

    shares = int(requested_shares)
    position_cap_shares = math.floor(portfolio_value * addon_position_cap / price)
    position_cap_room = max(0, position_cap_shares - current_shares)
    shares = min(shares, position_cap_room)
    cap_reason = "position_cap" if position_cap_room <= 0 else None

    heat_room_shares = None
    effective_stop = _position_heat_stop(portfolio_heat, ticker)
    if portfolio_heat and effective_stop is not None:
        total_at_risk = portfolio_heat.get("total_at_risk_usd", 0) or 0
        max_heat = portfolio_heat.get("max_heat_pct", MAX_PORTFOLIO_HEAT)
        heat_room_usd = max(0.0, portfolio_value * max_heat - total_at_risk)
        risk_per_share = max(0.0, price - effective_stop)
        if risk_per_share > 0:
            heat_room_shares = math.floor(heat_room_usd / risk_per_share)
            shares = min(shares, heat_room_shares)
            if heat_room_shares <= 0:
                cap_reason = "portfolio_heat_cap"

    if shares <= 0 and cap_reason is None:
        cap_reason = "no_cap_room"

    return max(0, int(shares)), {
        "requested_shares": int(requested_shares),
        "position_cap_room_shares": int(position_cap_room),
        "heat_room_shares": heat_room_shares,
        "effective_stop": effective_stop,
        "cap_reason": cap_reason,
    }


def build_early_relative_weakness_exit_actions(
    open_positions,
    ohlcv_dict,
    current_prices=None,
    current_price_dates=None,
    enabled=False,
    holding_rows=3,
    min_rs_vs_spy=-0.03,
    require_negative_return=True,
    reduce_pct=100,
    min_actual_risk_pct=None,
):
    """Return next-open exits for fresh positions that fail early vs SPY.

    The trigger is intentionally narrow and production-visible: after the Nth
    available holding-session close, the position must be negative from avg
    cost and trail SPY by at least `min_rs_vs_spy`.  A caller may also require
    a minimum production-known account risk percentage.
    """
    actions = []
    audit = []
    if not enabled:
        return actions, audit

    spy_df = (ohlcv_dict or {}).get("SPY")
    if spy_df is None or len(spy_df) == 0:
        return actions, [{
            "ticker": "SPY",
            "status": "skipped",
            "reason": "missing_spy_ohlcv_for_relative_strength",
        }]

    target_days_since_entry = max(0, int(holding_rows) - 1)
    actual_risk_threshold = None
    if min_actual_risk_pct is not None:
        try:
            actual_risk_threshold = float(min_actual_risk_pct)
            if not math.isfinite(actual_risk_threshold):
                actual_risk_threshold = None
        except (TypeError, ValueError):
            actual_risk_threshold = None
    current_prices = current_prices or {}
    current_price_dates = (
        None if current_price_dates is None else normalise_price_dates(current_price_dates)
    )

    for pos in _positive_positions(open_positions):
        ticker = str(pos.get("ticker", "")).upper()
        df = (ohlcv_dict or {}).get(ticker)
        if df is None or len(df) == 0:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "missing_ohlcv"})
            continue

        ticker_latest_date = _latest_ohlcv_date(df)
        spy_latest_date = _latest_ohlcv_date(spy_df)
        if not ticker_latest_date or not spy_latest_date:
            audit.append({
                "ticker": ticker,
                "status": "skipped",
                "reason": "missing_latest_ohlcv_date",
                "ticker_latest_date": ticker_latest_date,
                "spy_latest_date": spy_latest_date,
            })
            continue
        if ticker_latest_date != spy_latest_date:
            audit.append({
                "ticker": ticker,
                "status": "skipped",
                "reason": "mismatched_latest_ohlcv_date",
                "ticker_latest_date": ticker_latest_date,
                "spy_latest_date": spy_latest_date,
            })
            continue

        entry_date = pos.get("entry_date")
        if not entry_date:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "missing_entry_date"})
            continue

        entry_idx = _entry_index(df, entry_date)
        spy_entry_idx = _entry_index(spy_df, entry_date)
        if entry_idx is None or spy_entry_idx is None:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "entry_date_not_in_ohlcv"})
            continue

        today_idx = len(df.index) - 1
        days_since_entry = today_idx - entry_idx
        if days_since_entry != target_days_since_entry:
            audit.append({
                "ticker": ticker,
                "status": "skipped",
                "reason": "not_early_weakness_check_day",
                "days_since_entry": int(days_since_entry),
                "required_days_since_entry": target_days_since_entry,
                "holding_rows": int(holding_rows),
            })
            continue

        actual_risk_pct = None
        raw_actual_risk_pct = pos.get("actual_risk_pct")
        if raw_actual_risk_pct not in (None, ""):
            try:
                actual_risk_pct = float(raw_actual_risk_pct)
                if not math.isfinite(actual_risk_pct):
                    actual_risk_pct = None
            except (TypeError, ValueError):
                actual_risk_pct = None
        if actual_risk_threshold is not None and (
            actual_risk_pct is None or actual_risk_pct < actual_risk_threshold
        ):
            audit.append({
                "ticker": ticker,
                "status": "rejected",
                "reason": "actual_risk_below_threshold",
                "actual_risk_pct": (
                    round(actual_risk_pct, 6) if actual_risk_pct is not None else None
                ),
                "min_actual_risk_pct": round(actual_risk_threshold, 6),
            })
            continue

        entry_price = (
            pos.get("avg_cost")
            or pos.get("entry_price")
            or pos.get("entry_open_price")
            or _price_at(df, entry_idx, "Open")
        )
        close = _current_or_latest_close(
            df=df,
            ticker=ticker,
            current_prices=current_prices,
            current_price_dates=current_price_dates,
            required_date=ticker_latest_date,
        )
        spy_close = _latest_close(spy_df)
        spy_entry_open = _price_at(spy_df, spy_entry_idx, "Open")
        try:
            entry_price = float(entry_price)
        except (TypeError, ValueError):
            entry_price = None
        if not entry_price or not close or not spy_close or not spy_entry_open:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "missing_price"})
            continue

        ticker_return = (float(close) - entry_price) / entry_price
        spy_return = (float(spy_close) - float(spy_entry_open)) / float(spy_entry_open)
        rs_vs_spy = ticker_return - spy_return
        if rs_vs_spy > min_rs_vs_spy:
            audit.append({
                "ticker": ticker,
                "status": "rejected",
                "reason": "relative_weakness_threshold_not_met",
                "ticker_return_pct": round(ticker_return, 6),
                "spy_return_pct": round(spy_return, 6),
                "rs_vs_spy": round(rs_vs_spy, 6),
                "min_rs_vs_spy": min_rs_vs_spy,
            })
            continue
        if require_negative_return and ticker_return >= 0:
            audit.append({
                "ticker": ticker,
                "status": "rejected",
                "reason": "ticker_return_not_negative",
                "ticker_return_pct": round(ticker_return, 6),
                "spy_return_pct": round(spy_return, 6),
                "rs_vs_spy": round(rs_vs_spy, 6),
            })
            continue

        current_shares = int(pos.get("shares") or 0)
        shares_to_sell = partial_reduce_shares(current_shares, reduce_pct)
        if shares_to_sell <= 0:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "zero_shares_to_sell"})
            continue

        action = {
            "ticker": ticker,
            "action": "EXIT" if shares_to_sell >= current_shares else "REDUCE",
            "decision_mode": "code_early_relative_weakness_exit",
            "fill_timing": "next_session_open",
            "triggered_rule": "EARLY_RELATIVE_WEAKNESS",
            "exit_reason": "early_relative_weakness_exit",
            "holding_rows": int(holding_rows),
            "days_since_entry": int(days_since_entry),
            "entry_date": str(pd.Timestamp(entry_date).date()),
            "entry_price": round(entry_price, 4),
            "trigger_close": round(float(close), 4),
            "spy_entry_open": round(float(spy_entry_open), 4),
            "spy_trigger_close": round(float(spy_close), 4),
            "ticker_return_pct": round(ticker_return, 6),
            "spy_return_pct": round(spy_return, 6),
            "rs_vs_spy": round(rs_vs_spy, 6),
            "min_rs_vs_spy": min_rs_vs_spy,
            "require_negative_return": bool(require_negative_return),
            "actual_risk_pct": (
                round(actual_risk_pct, 6) if actual_risk_pct is not None else None
            ),
            "min_actual_risk_pct": (
                round(actual_risk_threshold, 6)
                if actual_risk_threshold is not None else None
            ),
            "reduce_pct": reduce_pct,
            "shares_before": current_shares,
            "shares_to_sell": shares_to_sell,
            "reason": (
                f"day-{holding_rows} early weakness: "
                f"return {ticker_return:.1%}, RS vs SPY {rs_vs_spy:.1%}"
            ),
        }
        actions.append(action)
        audit.append({"ticker": ticker, "status": "eligible", **action})

    return actions, audit


def build_followthrough_addon_actions(
    open_positions,
    ohlcv_dict,
    portfolio_value,
    current_prices,
    current_price_dates=None,
    portfolio_heat=None,
    addon_enabled=ADDON_ENABLED,
):
    """Return eligible add-on actions plus rejected audit rows.

    The timing mirrors backtester.py: a position is evaluated on the exact
    checkpoint close, and the resulting action is intended for next-session open.
    """
    actions = []
    audit = []
    if not addon_enabled:
        return actions, audit

    spy_df = (ohlcv_dict or {}).get("SPY")
    if spy_df is None or len(spy_df) == 0:
        return actions, [{
            "ticker": "SPY",
            "status": "skipped",
            "reason": "missing_spy_ohlcv_for_relative_strength",
        }]
    current_price_dates = (
        None if current_price_dates is None else normalise_price_dates(current_price_dates)
    )

    for pos in _positive_positions(open_positions):
        ticker = str(pos.get("ticker", "")).upper()
        df = (ohlcv_dict or {}).get(ticker)
        if df is None or len(df) == 0:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "missing_ohlcv"})
            continue

        ticker_latest_date = _latest_ohlcv_date(df)
        spy_latest_date = _latest_ohlcv_date(spy_df)
        if not ticker_latest_date or not spy_latest_date:
            audit.append({
                "ticker": ticker,
                "status": "skipped",
                "reason": "missing_latest_ohlcv_date",
                "ticker_latest_date": ticker_latest_date,
                "spy_latest_date": spy_latest_date,
            })
            continue
        if ticker_latest_date != spy_latest_date:
            audit.append({
                "ticker": ticker,
                "status": "skipped",
                "reason": "mismatched_latest_ohlcv_date",
                "ticker_latest_date": ticker_latest_date,
                "spy_latest_date": spy_latest_date,
            })
            continue

        entry_date = pos.get("entry_date")
        if not entry_date:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "missing_entry_date"})
            continue

        entry_idx = _entry_index(df, entry_date)
        spy_entry_idx = _entry_index(spy_df, entry_date)
        if entry_idx is None or spy_entry_idx is None:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "entry_date_not_in_ohlcv"})
            continue

        today_idx = len(df.index) - 1
        addon_count = int(pos.get("addon_count") or (1 if (pos.get("addon_shares") or 0) > 0 else 0))
        if addon_count >= (2 if SECOND_ADDON_ENABLED else 1):
            audit.append({"ticker": ticker, "status": "skipped", "reason": "addon_already_done"})
            continue

        if addon_count == 0:
            checkpoint_days = ADDON_CHECKPOINT_DAYS
            min_unrealized = ADDON_MIN_UNREALIZED_PCT
            min_rs = ADDON_MIN_RS_VS_SPY
            fraction = ADDON_FRACTION_OF_ORIGINAL_SHARES
            addon_position_cap = ADDON_MAX_POSITION_PCT
            spy_relative_leader_addon_cap = position_was_spy_relative_leader(
                pos,
                ticker_df=df,
                spy_df=spy_df,
                entry_idx=entry_idx,
                spy_entry_idx=spy_entry_idx,
            )
            if spy_relative_leader_addon_cap:
                addon_position_cap = ADDON_SPY_RELATIVE_LEADER_MAX_POSITION_PCT
        else:
            checkpoint_days = SECOND_ADDON_CHECKPOINT_DAYS
            min_unrealized = SECOND_ADDON_MIN_UNREALIZED_PCT
            min_rs = SECOND_ADDON_MIN_RS_VS_SPY
            fraction = SECOND_ADDON_FRACTION_OF_ORIGINAL_SHARES
            addon_position_cap = SECOND_ADDON_MAX_POSITION_PCT
            spy_relative_leader_addon_cap = False

        days_since_entry = today_idx - entry_idx
        if days_since_entry != checkpoint_days:
            audit.append({
                "ticker": ticker,
                "status": "skipped",
                "reason": "not_checkpoint_day",
                "days_since_entry": int(days_since_entry),
                "checkpoint_days": checkpoint_days,
            })
            continue

        close = _current_or_latest_close(
            df=df,
            ticker=ticker,
            current_prices=current_prices,
            current_price_dates=current_price_dates,
            required_date=ticker_latest_date,
        )
        spy_close = _latest_close(spy_df)
        if not close or not spy_close:
            audit.append({"ticker": ticker, "status": "skipped", "reason": "missing_close"})
            continue

        entry_close = float(df["Close"].iloc[entry_idx])
        spy_entry_close = float(spy_df["Close"].iloc[spy_entry_idx])
        avg_cost = pos.get("avg_cost") or entry_close
        unrealized = (close - avg_cost) / avg_cost
        ticker_ret = (close - entry_close) / entry_close
        spy_ret = (spy_close - spy_entry_close) / spy_entry_close
        rs_vs_spy = ticker_ret - spy_ret

        if unrealized < min_unrealized or rs_vs_spy <= min_rs:
            audit.append({
                "ticker": ticker,
                "status": "rejected",
                "reason": "followthrough_threshold_not_met",
                "unrealized_pct": round(unrealized, 4),
                "rs_vs_spy": round(rs_vs_spy, 4),
                "min_unrealized_pct": min_unrealized,
                "min_rs_vs_spy": min_rs,
            })
            continue

        current_shares = int(pos.get("shares") or 0)
        intended_shares, intended_source = resolve_intended_shares(pos)
        if intended_shares is not None:
            original_shares = intended_shares
            original_shares_source = intended_source
        else:
            original_shares = int(max(1, current_shares - int(pos.get("addon_shares") or 0)))
            original_shares_source = "current_shares_fallback"
        requested = math.floor(original_shares * fraction)
        shares, cap_detail = cap_followthrough_addon_shares(
            ticker,
            requested,
            current_shares,
            close,
            portfolio_value,
            addon_position_cap,
            portfolio_heat=portfolio_heat,
        )
        if shares <= 0:
            audit.append({
                "ticker": ticker,
                "status": "rejected",
                "reason": "addon_cap_no_room",
                **cap_detail,
            })
            continue

        action = {
            "ticker": ticker,
            "action": "ADD",
            "decision_mode": "code_followthrough_addon",
            "fill_timing": "next_session_open",
            "addon_number": addon_count + 1,
            "checkpoint_days": checkpoint_days,
            "days_since_entry": int(days_since_entry),
            "shares_to_buy": shares,
            "requested_shares": requested,
            "current_shares": current_shares,
            "original_shares": original_shares,
            "original_shares_source": original_shares_source,
            "estimated_price": round(close, 2),
            "estimated_position_value_usd": round(shares * close, 2),
            "unrealized_pct": round(unrealized, 4),
            "rs_vs_spy": round(rs_vs_spy, 4),
            "min_unrealized_pct": min_unrealized,
            "min_rs_vs_spy": min_rs,
            "addon_fraction_of_original_shares": fraction,
            "addon_position_cap_pct": addon_position_cap,
            "spy_relative_leader_addon_cap": spy_relative_leader_addon_cap,
            "cap_detail": cap_detail,
            "reason": (
                f"day-{checkpoint_days} follow-through: "
                f"unrealized {unrealized:.1%}, RS vs SPY {rs_vs_spy:.1%}"
            ),
        }
        actions.append(action)
        audit.append({"ticker": ticker, "status": "eligible", **action})

    return actions, audit
