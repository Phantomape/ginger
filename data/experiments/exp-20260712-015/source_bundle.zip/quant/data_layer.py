"""
Data Layer: Collect structured market and event data.

Provides:
  - OHLCV price data
  - Earnings event data (next date, EPS estimates, historical surprise)
  - Trading universe from watchlist
"""

import json
import logging
import os
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
import yfinance as yf

from yfinance_bootstrap import (
    configure_yfinance_runtime,
    download_with_rate_limit_retry,
)
from operator_input_paths import open_positions_path
from open_position_schema import account_position_tickers
from earnings_assets import empty_earnings_data, is_non_earnings_asset
from yf_negative_cache import clear as clear_no_fundamentals
from yf_negative_cache import is_blocked as is_no_fundamentals_cached
from yf_no_price_cache import clear as clear_no_price
from yf_no_price_cache import is_blocked as is_no_price_cached

logger = logging.getLogger(__name__)

configure_yfinance_runtime()

try:
    from filter import WATCHLIST
except ImportError:
    logger.warning("Could not import WATCHLIST from filter.py; using fallback")
    WATCHLIST = [
        "NVDA", "META", "AMD", "QQQ", "TSLA", "MCD", "CRDO",
        "IAU", "NFLX", "APP", "GOOG", "COIN", "MU",
    ]


def get_universe():
    """
    Return the trading universe: WATCHLIST + any tickers in open_positions.json.

    Mirrors the logic of trend_signals.get_universe() so no ticker is missed.
    """
    universe = set(WATCHLIST)

    path = open_positions_path()
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                positions = json.load(f)
            universe.update(account_position_tickers(positions))
        except Exception:
            pass

    return sorted(universe)


def _normalize_ohlcv_frame(ticker, data):
    if data is None or data.empty:
        logger.warning("%s: no OHLCV data returned", ticker)
        return None

    if isinstance(data.columns, pd.MultiIndex):
        ticker_key = str(ticker).upper()
        level0_key = next(
            (
                value
                for value in data.columns.get_level_values(0)
                if str(value).upper() == ticker_key
            ),
            None,
        )
        level1_key = next(
            (
                value
                for value in data.columns.get_level_values(1)
                if str(value).upper() == ticker_key
            ),
            None,
        )
        if level0_key is not None:
            data = data[level0_key]
        elif level1_key is not None:
            data = data.xs(level1_key, axis=1, level=1)
        else:
            logger.warning("%s: no OHLCV slice in bulk download", ticker)
            return None

    required = ["Open", "High", "Low", "Close", "Volume"]
    missing = [c for c in required if c not in data.columns]
    if missing:
        logger.warning("%s: missing columns %s", ticker, missing)
        return None

    data = data[required].dropna(how="all")

    # Drop any bar with no usable Close. The vendor often returns a partial
    # "today" row before the session has printed a price: OHLC are NaN while a
    # placeholder Volume keeps the row alive past dropna(how="all"). If that row
    # survives, iloc[-1] yields a NaN close that poisons every downstream price
    # comparison — breach status, exit signals, heat — and NaN comparisons fail
    # *open* into a false DELAYED_BREACH/CRITICAL_EXIT. Anchoring on the last bar
    # with a real Close keeps "current price" on the last valid trading day.
    data = data[data["Close"].notna()]
    if data.empty:
        logger.warning("%s: OHLCV slice empty after dropping blank rows", ticker)
        return None

    return data


def get_ohlcv(ticker, lookback_days=400):
    """
    Download daily OHLCV data for a ticker.

    400 calendar days is enough for 200-day MA + 52-week-high features.
    Returns a DataFrame with [Open, High, Low, Close, Volume], or None.
    """
    if is_no_price_cached(ticker):
        # Recently observed as delisted (no timezone) -- skip the wasted round-trip.
        logger.debug("%s: skipped OHLCV fetch (cached delisted)", ticker)
        return None
    try:
        end = datetime.now()
        start = end - timedelta(days=lookback_days)

        data = download_with_rate_limit_retry(
            ticker,
            start=start,
            end=end,
            progress=False,
            auto_adjust=True,
            retry_logger=logger,
        )

        normalized = _normalize_ohlcv_frame(ticker, data)
        if normalized is None:
            return None

        clear_no_price(ticker)  # real data -> self-heal any stale delisted entry
        logger.debug("%s: %s trading days downloaded", ticker, len(normalized))
        return normalized

    except Exception as e:
        logger.error("%s: OHLCV download failed - %s", ticker, e)
        return None


def get_ohlcv_many(tickers, lookback_days=400):
    """
    Download daily OHLCV data for many tickers in one vendor call.

    Missing or malformed slices fall back to the single-ticker path so callers
    keep the same best-effort behavior as repeated get_ohlcv() calls.
    """
    unique_tickers = list(dict.fromkeys(str(t).upper() for t in tickers if t))
    if not unique_tickers:
        return {}

    # Drop symbols recently observed as delisted (no timezone) so they never enter the
    # vendor call. They have no warehouse rows, so the refresh would otherwise re-fetch
    # them at full lookback every run, forever, for nothing.
    results = {}
    skipped = [t for t in unique_tickers if is_no_price_cached(t)]
    skipped_set = set(skipped)
    for ticker in skipped:
        logger.debug("%s: skipped OHLCV fetch (cached delisted)", ticker)
        results[ticker] = None
    fetch_tickers = [t for t in unique_tickers if t not in skipped_set]

    bulk = None
    if fetch_tickers:
        try:
            end = datetime.now()
            start = end - timedelta(days=lookback_days)
            ticker_arg = fetch_tickers if len(fetch_tickers) > 1 else fetch_tickers[0]
            bulk = download_with_rate_limit_retry(
                ticker_arg,
                start=start,
                end=end,
                progress=False,
                auto_adjust=True,
                group_by="ticker",
                threads=True,
                retry_logger=logger,
            )
        except Exception as e:
            logger.error("Bulk OHLCV download failed - %s", e)
            bulk = None

    for ticker in fetch_tickers:
        normalized = _normalize_ohlcv_frame(ticker, bulk)
        if normalized is not None:
            clear_no_price(ticker)  # real data -> self-heal any stale delisted entry
            logger.debug("%s: %s trading days downloaded", ticker, len(normalized))
        results[ticker] = normalized

    missing = [t for t in fetch_tickers if results.get(t) is None]
    if missing:
        logger.warning(
            "Bulk OHLCV missing %d/%d ticker(s); falling back individually: %s",
            len(missing),
            len(unique_tickers),
            missing,
        )
        for ticker in missing:
            results[ticker] = get_ohlcv(ticker, lookback_days=lookback_days)

    # Single aggregate line instead of one INFO per ticker — per-ticker detail
    # is at DEBUG. Spamming ~1200 lines buried the actual STEP 3 signal.
    ok_frames = [d for d in results.values() if d is not None]
    total_rows = sum(len(d) for d in ok_frames)
    logger.info(
        "OHLCV ready: %d/%d tickers, %d rows total%s%s",
        len(ok_frames),
        len(unique_tickers),
        total_rows,
        f", {len(unique_tickers) - len(ok_frames)} missing" if len(ok_frames) < len(unique_tickers) else "",
        f", {len(skipped)} skipped (cached delisted)" if skipped else "",
    )

    return results


def _coerce_as_of_date(as_of):
    """Normalize supported as_of inputs to a date object."""
    if as_of is None:
        return datetime.now().date()
    if isinstance(as_of, str):
        return pd.Timestamp(as_of).date()
    if hasattr(as_of, "date"):
        return as_of.date()
    return as_of


def _round_or_none(value, digits=4):
    """Return a rounded float or None for NaN/invalid values."""
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
        return round(float(value), digits)
    except Exception:
        return None


def _extract_earnings_dates_df(ticker_obj, ticker):
    """Fetch the broader earnings timeline once so callers can reuse it."""
    try:
        return ticker_obj.get_earnings_dates(limit=20)
    except Exception as e:
        logger.debug("%s: earnings dates unavailable - %s", ticker, e)
        return None


def _populate_from_earnings_dates(result, dates_df, as_of_date):
    """Fill result using only rows that would be knowable on as_of_date."""
    if dates_df is None or dates_df.empty:
        return

    df = dates_df.copy()
    df["_earnings_date"] = [pd.Timestamp(idx).date() for idx in df.index]
    df = df.sort_values("_earnings_date")

    if "Reported EPS" in df.columns:
        past = df[(df["_earnings_date"] <= as_of_date) & df["Reported EPS"].notna()]
        if not past.empty:
            latest_past = past.iloc[-1]
            last_date = latest_past["_earnings_date"]
            result["last_earnings_date"] = str(last_date)
            result["days_since_last_earnings"] = int(
                np.busday_count(last_date, as_of_date)
            )
            result["eps_actual_last"] = _round_or_none(latest_past.get("Reported EPS"))

            if "Surprise(%)" in past.columns:
                tail = past.tail(4)
                surprises = [
                    round(float(s), 2)
                    for s in tail["Surprise(%)"].tolist()
                    if not pd.isna(s)
                ]
                result["historical_surprise_pct"] = surprises
                if surprises:
                    result["avg_historical_surprise_pct"] = round(
                        sum(surprises) / len(surprises), 2
                    )

    future = df[df["_earnings_date"] > as_of_date]
    if future.empty:
        return

    next_row = future.iloc[0]
    next_date = next_row["_earnings_date"]
    result["next_earnings_date"] = str(next_date)
    result["days_to_earnings"] = int(np.busday_count(as_of_date, next_date))
    result["post_earnings_continuation_confirmed"] = bool(
        result.get("last_earnings_date") == str(as_of_date)
        and result.get("eps_actual_last") is not None
    )
    if result["post_earnings_continuation_confirmed"]:
        result["post_earnings_event_date"] = str(as_of_date)

    if "EPS Estimate" in next_row.index:
        result["eps_estimate"] = _round_or_none(next_row.get("EPS Estimate"))


def _populate_from_calendar(result, calendar, as_of_date):
    """Current-day fallback for next earnings date when earnings_dates lacks one."""
    if calendar is None:
        return

    if isinstance(calendar, pd.DataFrame) and "Earnings Date" in calendar.index:
        raw = calendar.loc["Earnings Date"].iloc[0]
    elif isinstance(calendar, dict) and "Earnings Date" in calendar:
        raw = calendar["Earnings Date"]
        if isinstance(raw, (list, tuple)) and raw:
            raw = raw[0]
    else:
        raw = None

    if raw is None or pd.isna(raw):
        return

    earnings_date = raw.date() if hasattr(raw, "date") else raw
    result["next_earnings_date"] = str(earnings_date)
    result["days_to_earnings"] = int(np.busday_count(as_of_date, earnings_date))


def _populate_from_info(result, info):
    """Current-day fallback for EPS estimate when no dated row is available."""
    if not isinstance(info, dict):
        return

    for key in ("forwardEps", "epsCurrentYear", "trailingEps"):
        value = _round_or_none(info.get(key))
        if value is not None:
            result["eps_estimate"] = value
            return


def get_earnings_data(
    ticker,
    as_of=None,
    *,
    ticker_obj=None,
    info=None,
    calendar=None,
    dates_df=None,
):
    """
    Get earnings event data from yfinance.

    When `as_of` is historical, only rows already knowable on that date are used.
    This avoids leaking future surprise history or future EPS estimates backward.
    """
    as_of_date = _coerce_as_of_date(as_of)
    current_mode = (as_of is None) or (as_of_date == datetime.now().date())
    result = empty_earnings_data()

    if is_non_earnings_asset(ticker):
        logger.debug("%s: earnings data skipped for non-earnings asset", ticker)
        return result

    # Skip symbols yfinance recently reported as delisted / lacking fundamentals,
    # unless the caller already prefetched the data for us (no request to save then).
    prefetched = (ticker_obj is not None) or (dates_df is not None)
    if not prefetched and current_mode and is_no_fundamentals_cached(ticker):
        logger.debug("%s: earnings request skipped (cached no-fundamentals)", ticker)
        return result

    try:
        ticker_obj = ticker_obj or yf.Ticker(ticker)
        if dates_df is None:
            dates_df = _extract_earnings_dates_df(ticker_obj, ticker)
        _populate_from_earnings_dates(result, dates_df, as_of_date)

        if current_mode and result["next_earnings_date"] is None:
            try:
                calendar = ticker_obj.calendar if calendar is None else calendar
                _populate_from_calendar(result, calendar, as_of_date)
            except Exception as e:
                logger.debug("%s: calendar unavailable - %s", ticker, e)

        if current_mode and result["eps_estimate"] is None:
            try:
                info = ticker_obj.info if info is None else info
                _populate_from_info(result, info)
            except Exception as e:
                logger.debug("%s: EPS estimate unavailable - %s", ticker, e)

        # Self-heal: a symbol that now returns real data should not stay suppressed.
        # Recording is left to the yfinance log filter, which keys off yfinance's own
        # explicit "no fundamentals / delisted" signal (precise; no false positives on
        # a valid stock that merely has no upcoming earnings date this week).
        if current_mode and not prefetched and (
            result["next_earnings_date"] or result["eps_estimate"]
        ):
            clear_no_fundamentals(ticker)

    except Exception as e:
        logger.error("%s: earnings data collection failed - %s", ticker, e)

    return result
