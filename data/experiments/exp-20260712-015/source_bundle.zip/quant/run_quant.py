"""
Quant Pipeline Entry Point.

Run daily to generate signals, compute risk/sizing, and produce the report.

Usage:
    cd d:/Github/ginger/quant
    python run_quant.py

Output:
    - Console: formatted daily report
    - data/daily/reports/report_YYYYMMDD.txt
    - data/daily/signals/quant/quant_signals_YYYYMMDD.json
      (full signal + feature data)
"""

import os
import json
import logging
from datetime import datetime

from constants import (
    ATR_TARGET_MULT,
    BREAKOUT_MAX_PULLBACK_FROM_52W_HIGH,
    BREAKOUT_RANK_BY_52W_HIGH,
    ENABLED_STRATEGIES,
    REGIME_AWARE_EXIT,
)
from earnings_snapshot import persist_earnings_snapshot
from data_paths import daily_artifact_path, atomic_write_json
from operator_input_paths import open_positions_path, repo_relative
from open_position_schema import account_positions, has_account_positions
from regime_exit import compute_regime_exit_profile

# ── Logging setup ────────────────────────────────────────────────────────────

def _setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s  %(levelname)-7s  %(name)s: %(message)s',
        datefmt='%H:%M:%S',
    )

# ── Helpers ──────────────────────────────────────────────────────────────────

def _load_open_positions():
    """Load open_positions.json from operator inputs."""
    path = open_positions_path()
    if path.exists():
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logging.getLogger(__name__).error(
                f"open_positions.json at {repo_relative(path)} is unreadable/malformed: {e}. "
                "Treating as no open positions; fix the file and re-run."
            )
            return None
    logging.getLogger(__name__).warning(
        f"open_positions.json not found at {repo_relative(path)}"
    )
    return None


def _save_json(obj, filepath):
    # Atomic write (temp + os.replace); see bug audit #9.
    atomic_write_json(obj, filepath, default=str)


# ── Pipeline ─────────────────────────────────────────────────────────────────

def main():
    _setup_logging()
    log = logging.getLogger(__name__)

    log.info("=" * 50)
    log.info("Quant pipeline starting")
    log.info("=" * 50)

    # ── Imports (local to quant/) ────────────────────────────────────────────
    from data_layer       import get_universe, get_ohlcv, get_earnings_data
    from feature_layer    import compute_features
    from signal_engine    import generate_signals, rank_signals_for_allocation
    from risk_engine      import enrich_signals
    from portfolio_engine import size_signals, compute_portfolio_heat
    from performance_engine import compute_metrics
    from report_generator import generate_daily_report, save_report

    # ── Market regime ────────────────────────────────────────────────────────
    try:
        from regime import compute_market_regime
        log.info("Computing market regime (SPY/QQQ vs 200-day MA)...")
        market_regime = compute_market_regime()
        log.info(f"Regime: {market_regime['regime']}")
    except Exception as e:
        log.warning(f"Market regime unavailable: {e}")
        market_regime = {"regime": "UNKNOWN", "note": str(e), "indices": {}}

    # ── Step 1: Universe ─────────────────────────────────────────────────────
    universe = get_universe()
    log.info(f"Universe ({len(universe)} tickers): {universe}")

    # ── Step 2: Data Layer ───────────────────────────────────────────────────
    log.info("Downloading OHLCV data...")
    ohlcv_dict = {}
    for ticker in universe:
        ohlcv_dict[ticker] = get_ohlcv(ticker)

    log.info("Fetching earnings data...")
    earnings_dict = {}
    for ticker in universe:
        earnings_dict[ticker] = get_earnings_data(ticker)
    persist_earnings_snapshot(earnings_dict, as_of=datetime.now(), logger=log)

    # ── Step 3: Feature Layer ────────────────────────────────────────────────
    log.info("Computing features...")
    features_dict = {}
    for ticker in universe:
        features_dict[ticker] = compute_features(
            ticker, ohlcv_dict[ticker], earnings_dict[ticker]
        )

    feature_count = sum(1 for f in features_dict.values() if f is not None)
    log.info(f"Features computed for {feature_count}/{len(universe)} tickers")

    # ── Step 4: Signal Engine ────────────────────────────────────────────────
    # Build market_context in the format expected by signal_engine:
    #   "market_regime": "BULL" | "NEUTRAL" | "BEAR"
    #   "spy_10d_return": float (SPY 10-day momentum, used by RS filter)
    mc = {"market_regime": market_regime.get("regime", "")}
    spy_data = market_regime.get("indices", {}).get("SPY", {})
    qqq_data = market_regime.get("indices", {}).get("QQQ", {})
    if spy_data.get("momentum_10d_pct") is not None:
        mc["spy_10d_return"] = spy_data["momentum_10d_pct"]
    if qqq_data.get("momentum_10d_pct") is not None:
        mc["qqq_10d_return"] = qqq_data["momentum_10d_pct"]
    if spy_data.get("pct_from_ma") is not None:
        mc["spy_pct_from_ma"] = spy_data["pct_from_ma"]
    if qqq_data.get("pct_from_ma") is not None:
        mc["qqq_pct_from_ma"] = qqq_data["pct_from_ma"]

    log.info("Generating signals...")
    signals = generate_signals(
        features_dict,
        market_context=mc,
        enabled_strategies=ENABLED_STRATEGIES,
        breakout_max_pullback_from_52w_high=BREAKOUT_MAX_PULLBACK_FROM_52W_HIGH,
    )
    if BREAKOUT_RANK_BY_52W_HIGH:
        signals = rank_signals_for_allocation(signals)
    log.info(f"Signals: {len(signals)} triggered")

    # ── Step 5: Risk Engine ──────────────────────────────────────────────────
    exit_profile = compute_regime_exit_profile(mc, base_target_mult=ATR_TARGET_MULT)
    atr_target_mult = exit_profile["target_mult"] if REGIME_AWARE_EXIT else ATR_TARGET_MULT
    if REGIME_AWARE_EXIT:
        log.info(
            "Regime-aware exit active: "
            f"bucket={exit_profile['bucket']} score={exit_profile['score']} "
            f"target_mult={atr_target_mult:.2f}"
        )
    signals = enrich_signals(signals, features_dict, atr_target_mult=atr_target_mult)
    if REGIME_AWARE_EXIT:
        for s in signals:
            s["target_mult_used"] = exit_profile["target_mult"]
            s["regime_exit_bucket"] = exit_profile["bucket"]
            s["regime_exit_score"] = exit_profile["score"]

    # ── Step 6: Portfolio Engine ─────────────────────────────────────────────
    open_positions  = _load_open_positions()
    stored_pv       = (open_positions or {}).get("portfolio_value_usd")

    # Current prices from features (needed before portfolio value calculation)
    current_prices = {
        t: f["close"]
        for t, f in features_dict.items()
        if f and f.get("close") is not None
    }

    # Auto-compute live portfolio value from current market prices × shares.
    # portfolio_value_usd in open_positions.json is manually maintained and can be
    # stale by weeks or months.  A stale denominator inflates heat_pct by the ratio
    # (actual_value / stale_value), causing the 8% cap to trigger prematurely and
    # blocking all new trades.  Example: stored $70k, actual $150k → heat appears 2×
    # worse than reality, permanently barring new positions.
    portfolio_value = stored_pv
    if has_account_positions(open_positions, positive_only=True):
        equity_pv = sum(
            pos.get("shares", 0) * current_prices.get(pos.get("ticker", ""), pos.get("avg_cost", 0))
            for pos in account_positions(open_positions, positive_only=True)
        )
        # Include cash balance so sizing and heat reflect the full account value.
        # Without cash: a $100k account with $60k invested computes PV=$60k →
        # positions sized for 0.6% risk (not 1%) and heat appears 1.67× inflated.
        # Add cash_usd field to open_positions.json to enable correct calculation.
        cash_raw = open_positions.get("cash_usd")
        if cash_raw is None:
            if stored_pv:
                log.warning(
                    f"⚠️  cash_usd missing in open_positions.json — using stored "
                    f"portfolio_value_usd={stored_pv:,.0f} USD for heat and sizing. "
                    f"Fill cash_usd to enable live PV."
                )
        else:
            live_pv = equity_pv + cash_raw
            if live_pv > 0:
                if stored_pv and abs(live_pv - stored_pv) / stored_pv > 0.15:
                    log.warning(
                        f"⚠️  Portfolio value drift detected: stored={stored_pv:,.0f} USD  "
                        f"live={live_pv:,.0f} USD  (equity={equity_pv:,.0f} + cash={cash_raw:,.0f}).  "
                        f"Using live value for heat and sizing calculations. "
                        f"Update portfolio_value_usd in open_positions.json to suppress this warning."
                    )
                portfolio_value = live_pv
                log.info(f"Portfolio value: live={live_pv:,.0f} USD (stored={stored_pv or 'N/A'})")
            elif stored_pv:
                # Fallback: positions have no current price data (e.g. yfinance failure)
                log.warning(
                    f"Could not compute live portfolio value (no current prices for positions). "
                    f"Falling back to stored value: {stored_pv:,.0f} USD."
                )
    elif stored_pv:
        # Stale portfolio data warning
        if open_positions and open_positions.get("as_of"):
            try:
                as_of_dt   = datetime.strptime(open_positions["as_of"], "%Y-%m-%d")
                days_stale = (datetime.now() - as_of_dt).days
                if days_stale > 30:
                    log.warning(
                        f"⚠️  open_positions.json is {days_stale} days stale "
                        f"(as_of={open_positions['as_of']}). "
                        f"Update portfolio_value_usd to current account value."
                    )
            except Exception:
                pass

    portfolio_heat = None
    if open_positions and portfolio_value:
        # Pass features_dict so effective stops (ATR/trailing) are used for
        # large winners — without it, heat falls back to hard_stop only and
        # overstates at-risk USD for positions with >100% unrealised gains.
        portfolio_heat = compute_portfolio_heat(
            open_positions, current_prices, portfolio_value,
            features_dict=features_dict,
        )
        log.info(portfolio_heat["heat_note"])
    else:
        log.warning("Set portfolio_value_usd in open_positions.json to enable heat tracking")

    # Add position sizing to signals
    if portfolio_value:
        signals = size_signals(signals, portfolio_value)

    # ── Step 7: Performance Engine ───────────────────────────────────────────
    metrics = compute_metrics(portfolio_value=portfolio_value)
    if metrics.get("total_trades", 0) > 0:
        log.info(
            f"P&L  trades={metrics['total_trades']}  "
            f"WR={metrics['win_rate']*100:.0f}%  "
            f"EV=${metrics['expected_value_usd']:,.2f}  "
            f"total=${metrics['total_pnl_usd']:,.2f}"
        )
    else:
        log.info(metrics.get("note", "No closed trades yet"))

    # ── Step 8: Report ───────────────────────────────────────────────────────
    report = generate_daily_report(
        signals        = signals,
        features_dict  = features_dict,
        portfolio_heat = portfolio_heat,
        metrics        = metrics,
        market_regime  = market_regime,
        open_positions = open_positions,
    )

    print("\n" + report)

    report_path = save_report(report)
    if report_path:
        log.info(f"Report → {report_path}")

    # ── Save full signals JSON ───────────────────────────────────────────────
    today        = datetime.now().strftime("%Y%m%d")
    signals_path = str(daily_artifact_path("quant_signals", today))
    _save_json({
        "generated_at":   datetime.now().isoformat(),
        "market_regime":  market_regime,
        "portfolio_heat": portfolio_heat,
        "signals":        signals,
        "features":       features_dict,
    }, signals_path)
    log.info(f"Signals JSON → {signals_path}")

    log.info("Quant pipeline complete.")
    return signals


if __name__ == "__main__":
    main()
